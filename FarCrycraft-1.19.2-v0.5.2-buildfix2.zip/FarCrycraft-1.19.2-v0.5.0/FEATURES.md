# Feature map

WEAPONS: done (core)
ATTACHMENTS: done (NBT + bench cycle)
WEAPON BENCH: done (functional interaction)
FPS FIRE INPUT: done (network packet)
RELOAD: done (network packet)
EXPLOSIVES: done (prototype)
PARACHUTE: done (network glide state)
ENEMY ROLES: done (prototype)
OUTPOSTS: done (procedural prototype)
VEHICLES: done (foundation: 4 types)
AIRPLANE: done (foundation/controller)
HUD: done (basic)
3D WEAPON MODELS: done (original cube meshes)
3D ENEMY MODEL: done (humanoid + role pose)
ANIMATION SOURCES: done (Blockbench/GeckoLib source rigs)

PRODUCTION ART PASS: continue
FULL VEHICLE MESHES: continue
FULL ANIMATION SET: continue
FULL OUTPOST ALARM/STEALTH/CAPTURE LOOP: continue

## Finalized control layout
- TAB: weapon wheel with exactly 3 long-gun slots + pistol + equipment.
- The machete is not a wheel slot.
- V: contextual takedown; the machete is only visually/animation-wise used during the takedown.
- SHIFT + click on a downed body: start dragging.
- Release SHIFT: stop dragging.
- Enemy weapons have finite magazines, reserves, and reload states.

## Smart enemy AI v0.5.x
- Real magazine + reserve ammo for every enemy class.
- Reload state and different reload lengths per role.
- Hearing gunshots and moving to the last known shooter position.
- Allies share target/alert information.
- Search state after losing line of sight.
- Role-aware preferred combat distances.
- Dynamic cover selection and reload-from-cover behavior.
- Sniper distance keeping, MG suppression, heavy push and light flanking.
- Persistent downed/corpse state.
- Contextual V takedown and Shift-drag body interaction.

## Military world / vehicles
- Three random military site types: checkpoint, military base, airfield.
- Bases have perimeter walls, gates, towers, command buildings, loot and defenders.
- Airfields can contain an airplane, helicopter and truck.
- Military bases can contain trucks and cars.
- Sites can trigger an alarm when defenders acquire line of sight to the player.
- Reinforcements can arrive from outside the site perimeter.
- Vehicles have distinct car, truck, helicopter and airplane handling foundations.
- Vehicle controls are sent from client to server while driving.

## Weapon draw / holster animation
- Equipping a weapon now has a dedicated draw-up animation.
- Switching directly between two guns lowers the current gun before bringing the new gun up.
- Moving to a non-weapon hotbar slot plays a short holster/lower animation.
- Holding TAB opens the wheel and lowers the held weapon so the selection UI is clear.
- Releasing TAB applies the selected wheel slot and plays the draw animation.

## Night vision + thermal goggles
- Wearable head-slot item: Night Vision Goggles.
- Tap N while wearing them: night vision ON/OFF.
- Hold N while night vision is active: thermal mode.
- Release N: return from thermal to normal night vision.
- Thermal mode outlines nearby living entities and applies a subtle HUD tint.
- Goggles are visible as a transparent head armor texture.

## Night-vision goggles model / animations
- Original 3D tactical goggles model attached to the player head.
- Lens pods flip down when night vision is activated and lift when deactivated.
- Thermal filters slide/tilt over the lenses during N-hold thermal mode.
- Mode switches have a short mechanical pulse animation.
- Source geometry and animation JSON are included under `assets/farcrycraft/geo` and `animations`.

## Arm customization / pause-menu arms icon
- Pause menu (ESC) gets a small arms icon button.
- The button opens the Arm Customization screen without leaving the world.
- Skin tone can be changed through presets.
- Sleeve color can be changed through presets.
- Gloves can be toggled.
- Wrist band can be toggled.
- Sleeve style cycles between rolled, short and long.
- Settings persist to `config/farcrycraft_arms.json` on the client.
- First-person arms use a separate model with independently tinted sleeve, skin and hand parts.

## Stealth bushes
- New stealth bush block with cutout foliage.
- Crouching inside a bush makes the player visually hidden from mercenary AI.
- Sprinting, standing up, or firing breaks stealth.
- Bush patches are generated around explored areas and around military outposts.
- HUD shows STEALTH / HIDDEN IN BUSH while concealed.


## Polish / stability pass
- Removed duplicate reload/parachute key registration so each key has one authoritative client handler.
- Updated GUI rendering code to the Minecraft 1.19.2 PoseStack API.
- Added missing stealth-bush blockstate, block model and item model.
- Stealth-bush model uses cutout rendering for proper transparent foliage.
- Enemy magazine initialization now respects the actual role (sniper/MG/heavy/default).
- Gunshots now notify nearby mercenaries and break bush stealth only after a live round is fired.
- Player reloads are now server-timed rather than instantly refilling on packet receipt.
- Reduced bush generation frequency/density to prevent excessive world clutter.

## NPC vehicle crews
- Military vehicles can be boarded by mercenary NPCs.
- The first NPC passenger is the driver/pilot.
- Cars/trucks can be used as pursuit vehicles.
- Helicopters/airplanes get a pilot crew member.
- Trucks and helicopters can spawn a machine-gunner passenger.
- NPC passengers can fire at the player while mounted.
- Ground-vehicle drivers dismount near their target and resume infantry combat.
