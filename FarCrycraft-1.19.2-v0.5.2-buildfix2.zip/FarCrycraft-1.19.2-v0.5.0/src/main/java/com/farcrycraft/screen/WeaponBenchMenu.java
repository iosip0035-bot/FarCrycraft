package com.farcrycraft.screen;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
public class WeaponBenchMenu extends AbstractContainerMenu {
 public WeaponBenchMenu(int id,Inventory inv){super(MenuType.GENERIC_9x3,id);}
 @Override public boolean stillValid(Player p){return true;}
}
