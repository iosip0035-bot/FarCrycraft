package com.farcrycraft.registry;
import com.farcrycraft.FarCrycraft;
import com.farcrycraft.item.WeaponItem;
import com.farcrycraft.item.VehicleItem;
import com.farcrycraft.entity.FarCryVehicleEntity;
import com.farcrycraft.item.WeaponSpecs;
import com.farcrycraft.item.ThrowableExplosiveItem;
import com.farcrycraft.item.MedkitItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraftforge.registries.*;
public final class ModItems {
 public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS,FarCrycraft.MODID);
 public static final RegistryObject<Item> PISTOL=gun("pistol",WeaponSpecs.PISTOL);
 public static final RegistryObject<Item> SMG=gun("smg",WeaponSpecs.SMG);
 public static final RegistryObject<Item> ASSAULT_RIFLE=gun("assault_rifle",WeaponSpecs.ASSAULT_RIFLE);
 public static final RegistryObject<Item> CARBINE=gun("carbine",WeaponSpecs.CARBINE);
 public static final RegistryObject<Item> LMG=gun("lmg",WeaponSpecs.LMG);
 public static final RegistryObject<Item> SHOTGUN=gun("shotgun",WeaponSpecs.SHOTGUN);
 public static final RegistryObject<Item> DMR=gun("dmr",WeaponSpecs.DMR);
 public static final RegistryObject<Item> SNIPER=gun("sniper",WeaponSpecs.SNIPER);
 public static final RegistryObject<Item> RPG=gun("rpg",WeaponSpecs.RPG);
 public static final RegistryObject<Item> PISTOL_AMMO=ammo("pistol_ammo");
 public static final RegistryObject<Item> RIFLE_AMMO=ammo("rifle_ammo");
 public static final RegistryObject<Item> SHOTGUN_SHELLS=ammo("shotgun_shells");
 public static final RegistryObject<Item> ROCKET=ammo("rocket");
 public static final RegistryObject<Item> MACHETE=ITEMS.register("machete",()->new com.farcrycraft.item.MacheteItem());
 public static final RegistryObject<Item> STEALTH_BUSH=ITEMS.register("stealth_bush",()->new BlockItem(ModBlocks.STEALTH_BUSH.get(),new Item.Properties()));
 public static final RegistryObject<Item> FRAG=ITEMS.register("frag_grenade",()->new ThrowableExplosiveItem(ThrowableExplosiveItem.Kind.FRAG));
 public static final RegistryObject<Item> INCENDIARY=ITEMS.register("incendiary_grenade",()->new ThrowableExplosiveItem(ThrowableExplosiveItem.Kind.INCENDIARY));
 public static final RegistryObject<Item> MINE=ITEMS.register("mine",()->new ThrowableExplosiveItem(ThrowableExplosiveItem.Kind.MINE));
 public static final RegistryObject<Item> C4=ITEMS.register("c4",()->new ThrowableExplosiveItem(ThrowableExplosiveItem.Kind.C4));
 public static final RegistryObject<Item> MEDKIT=ITEMS.register("medkit",()->new MedkitItem());
 public static final RegistryObject<Item> NIGHT_VISION_GOGGLES=ITEMS.register("night_vision_goggles",()->new com.farcrycraft.item.NightVisionGogglesItem());
 public static final RegistryObject<Item> PARACHUTE=ITEMS.register("parachute",()->new Item(new Item.Properties().stacksTo(1)));
 public static final RegistryObject<Item> CAR_KEY=ITEMS.register("car_key",()->new VehicleItem(FarCryVehicleEntity.Type.CAR));
 public static final RegistryObject<Item> TRUCK_KEY=ITEMS.register("truck_key",()->new VehicleItem(FarCryVehicleEntity.Type.TRUCK));
 public static final RegistryObject<Item> HELICOPTER_KEY=ITEMS.register("helicopter_key",()->new VehicleItem(FarCryVehicleEntity.Type.HELICOPTER));
 public static final RegistryObject<Item> AIRPLANE_KEY=ITEMS.register("airplane_key",()->new VehicleItem(FarCryVehicleEntity.Type.AIRPLANE));
 private static RegistryObject<Item> ammo(String id){return ITEMS.register(id,()->new Item(new Item.Properties()));}
 private static RegistryObject<Item> gun(String id,WeaponSpecs.Spec s){return ITEMS.register(id,()->new WeaponItem(s));}
 private ModItems(){}
}
