package com.farcrycraft.registry;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.entity.FarCryVehicleEntity;
import com.farcrycraft.entity.MercenaryEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
        DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FarCrycraft.MODID);

    public static final RegistryObject<EntityType<MercenaryEntity>> MERCENARY = enemy("mercenary");
    public static final RegistryObject<EntityType<MercenaryEntity>> HEAVY = enemy("heavy_mercenary");
    public static final RegistryObject<EntityType<MercenaryEntity>> SNIPER = enemy("sniper");
    public static final RegistryObject<EntityType<MercenaryEntity>> MG = enemy("machine_gunner");

    public static final RegistryObject<EntityType<FarCryVehicleEntity>> VEHICLE = ENTITIES.register("vehicle", () ->
        EntityType.Builder.of(FarCryVehicleEntity::new, MobCategory.MISC)
            .sized(1.6f, 1.1f)
            .clientTrackingRange(96)
            .updateInterval(1)
            .build("vehicle"));

    private static RegistryObject<EntityType<MercenaryEntity>> enemy(String id) {
        return ENTITIES.register(id, () -> EntityType.Builder.<MercenaryEntity>of(
            (t, l) -> new MercenaryEntity(t, l, id), MobCategory.MONSTER)
            .sized(.65f, 1.9f).clientTrackingRange(64).build(id));
    }

    @Mod.EventBusSubscriber(modid = FarCrycraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Attrs {
        @SubscribeEvent public static void create(EntityAttributeCreationEvent e) {
            var a = MercenaryEntity.attributes().build();
            e.put(MERCENARY.get(), a);
            e.put(HEAVY.get(), a);
            e.put(SNIPER.get(), a);
            e.put(MG.get(), a);
        }
    }

    private ModEntities() {}
}
