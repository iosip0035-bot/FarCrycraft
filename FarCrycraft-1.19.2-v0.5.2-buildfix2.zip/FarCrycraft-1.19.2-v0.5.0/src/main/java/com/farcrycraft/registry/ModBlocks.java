package com.farcrycraft.registry;
import com.farcrycraft.FarCrycraft;
import com.farcrycraft.block.WeaponBenchBlock;
import com.farcrycraft.block.StealthBushBlock;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.registries.*;
public final class ModBlocks {
 public static final DeferredRegister<Block> BLOCKS=DeferredRegister.create(ForgeRegistries.BLOCKS,FarCrycraft.MODID);
 public static final RegistryObject<Block> WEAPON_BENCH=BLOCKS.register("weapon_bench",()->new WeaponBenchBlock(BlockBehaviour.Properties.of(Material.WOOD).strength(2.5f)));
 public static final RegistryObject<Block> STEALTH_BUSH=BLOCKS.register("stealth_bush",StealthBushBlock::new);
 private ModBlocks(){}
}
