package com.farcrycraft.item;

import com.farcrycraft.entity.FarCryVehicleEntity;
import com.farcrycraft.registry.ModEntities;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class VehicleItem extends Item {
    private final FarCryVehicleEntity.Type type;
    public VehicleItem(FarCryVehicleEntity.Type type) {
        super(new Item.Properties().stacksTo(1));
        this.type = type;
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            FarCryVehicleEntity v = new FarCryVehicleEntity(ModEntities.VEHICLE.get(), level);
            v.setType(type);
            v.setPos(player.getX() + player.getLookAngle().x * 3.0,
                     player.getY(),
                     player.getZ() + player.getLookAngle().z * 3.0);
            level.addFreshEntity(v);
            player.startRiding(v);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
