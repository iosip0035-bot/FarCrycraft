package com.farcrycraft.item;

import java.util.EnumSet;

public final class WeaponSpecs {
 public enum Attachment { RED_DOT, HOLO, SCOPE, SUPPRESSOR, EXTENDED_MAG, GRIP, MUZZLE_BRAKE }
 public record Spec(String id,int mag,int reserve,int pellets,float damage,float spread,float range,int cooldown){}
 public static final Spec PISTOL=new Spec("pistol",15,120,1,7.5f,.010f,34,4);
 public static final Spec SMG=new Spec("smg",32,192,1,5f,.032f,28,2);
 public static final Spec ASSAULT_RIFLE=new Spec("assault_rifle",30,210,1,7f,.018f,42,3);
 public static final Spec CARBINE=new Spec("carbine",30,210,1,8f,.014f,48,4);
 public static final Spec LMG=new Spec("lmg",75,300,1,6.5f,.026f,45,2);
 public static final Spec SHOTGUN=new Spec("shotgun",8,64,8,5f,.085f,18,11);
 public static final Spec DMR=new Spec("dmr",20,140,1,12f,.009f,65,7);
 public static final Spec SNIPER=new Spec("sniper",5,45,1,32f,.003f,110,25);
 public static final Spec RPG=new Spec("rpg",1,12,1,0f,0f,80,35);
 public static EnumSet<Attachment> defaults(String id){
   return switch(id){
     case "pistol" -> EnumSet.of(Attachment.RED_DOT);
     case "smg" -> EnumSet.of(Attachment.SUPPRESSOR);
     case "assault_rifle" -> EnumSet.of(Attachment.RED_DOT,Attachment.GRIP);
     case "carbine" -> EnumSet.of(Attachment.HOLO);
     case "lmg" -> EnumSet.of(Attachment.EXTENDED_MAG,Attachment.GRIP);
     case "shotgun" -> EnumSet.of(Attachment.MUZZLE_BRAKE);
     case "dmr","sniper" -> EnumSet.of(Attachment.SCOPE);
     default -> EnumSet.noneOf(Attachment.class);
   };
 }
 private WeaponSpecs(){}
}
