package com.farcrycraft.item;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterials;
import net.minecraft.world.item.ItemStack;

/** Wearable head-slot NV goggles. The N key activates the electronics. */
public class NightVisionGogglesItem extends ArmorItem {
    public NightVisionGogglesItem() {
        super(ArmorMaterials.IRON, Type.HELMET, new net.minecraft.world.item.Item.Properties().stacksTo(1));
    }

    @Override
    public String getArmorTexture(ItemStack stack, net.minecraft.world.entity.Entity entity,
                                   EquipmentSlot slot, String type) {
        return "farcrycraft:textures/models/armor/night_vision_goggles_layer_1.png";
    }
}
