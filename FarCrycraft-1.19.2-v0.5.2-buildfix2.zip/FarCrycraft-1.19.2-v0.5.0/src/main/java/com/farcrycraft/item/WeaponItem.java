package com.farcrycraft.item;
import com.farcrycraft.common.WeaponSystem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
public class WeaponItem extends Item {
 private final WeaponSpecs.Spec spec;
 public WeaponItem(WeaponSpecs.Spec spec){super(new Item.Properties().stacksTo(1));this.spec=spec;}
 public WeaponSpecs.Spec spec(){return spec;}
 public static void init(ItemStack s,WeaponSpecs.Spec spec){CompoundTag n=s.getOrCreateTag();if(!n.contains("Ammo"))n.putInt("Ammo",spec.mag());if(!n.contains("Reserve"))n.putInt("Reserve",spec.reserve());if(!n.contains("Attachments"))n.putString("Attachments",String.join(",",WeaponSpecs.defaults(spec.id()).stream().map(Enum::name).toList()));}
 @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){ItemStack s=player.getItemInHand(hand);init(s,spec);if(!level.isClientSide)WeaponSystem.fire(player,s,spec);return InteractionResultHolder.sidedSuccess(s,level.isClientSide());}
}
