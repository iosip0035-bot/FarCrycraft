package com.farcrycraft.item;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ThrowableExplosiveItem extends Item {
    public enum Kind { FRAG, INCENDIARY, MINE, C4 }
    private final Kind kind;
    public ThrowableExplosiveItem(Kind kind) {
        super(new Item.Properties().stacksTo(kind == Kind.C4 ? 8 : 16));
        this.kind = kind;
    }
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            double x = player.getX();
            double y = player.getY() + 1.0;
            double z = player.getZ();
            float power = switch (kind) {
                case FRAG -> 3.2f;
                case INCENDIARY -> 2.0f;
                case MINE -> 2.8f;
                case C4 -> 4.5f;
            };
            level.explode(player, x, y, z, power, net.minecraft.world.level.Explosion.BlockInteraction.DESTROY);
            if (kind == Kind.INCENDIARY)
                level.addParticle(ParticleTypes.FLAME, x, y, z, 0, .08, 0);
            level.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE,
                SoundSource.PLAYERS, .65f, 1.15f);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
