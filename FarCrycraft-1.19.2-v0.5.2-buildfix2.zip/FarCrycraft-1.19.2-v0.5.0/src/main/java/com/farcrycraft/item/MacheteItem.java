package com.farcrycraft.item;

import net.minecraft.world.item.Item;

public class MacheteItem extends Item {
    public MacheteItem() {
        super(new Item.Properties().stacksTo(1).durability(250));
    }
}
