package com.farcrycraft.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public class FarCryVehicleEntity extends Entity {
    public enum Type { CAR, TRUCK, HELICOPTER, AIRPLANE }

    private Type type = Type.CAR;
    private float health = 120f;
    private int idleTicks;

    public FarCryVehicleEntity(net.minecraft.world.entity.EntityType<? extends FarCryVehicleEntity> type, Level level) {
        super(type, level);
    }

    public Type getVehicleType() { return type; }
    public void setType(Type type) { this.type = type; }
    public float getVehicleHealth() { return health; }
    public boolean isFull() { return getPassengers().size() >= seatCount(); }

    private int seatCount() {
        return switch (type) {
            case CAR -> 2;
            case TRUCK -> 4;
            case HELICOPTER -> 4;
            case AIRPLANE -> 2;
        };
    }

    @Override
    protected void defineSynchedData() {}

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("VehicleType")) type = Type.valueOf(tag.getString("VehicleType"));
        health = tag.getFloat("VehicleHealth");
        if (health <= 0) health = 120f;
        if (tag.contains("CruiseX")) getPersistentData().putDouble("CruiseX", tag.getDouble("CruiseX"));
        if (tag.contains("CruiseY")) getPersistentData().putDouble("CruiseY", tag.getDouble("CruiseY"));
        if (tag.contains("CruiseZ")) getPersistentData().putDouble("CruiseZ", tag.getDouble("CruiseZ"));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("VehicleType", type.name());
        tag.putFloat("VehicleHealth", health);
        if (getPersistentData().contains("CruiseX")) {
            tag.putDouble("CruiseX", getPersistentData().getDouble("CruiseX"));
            tag.putDouble("CruiseY", getPersistentData().getDouble("CruiseY"));
            tag.putDouble("CruiseZ", getPersistentData().getDouble("CruiseZ"));
        }
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().size() < seatCount() &&
            (passenger instanceof Player || passenger instanceof MercenaryEntity);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (getCommandSenderWorld().isClientSide) return InteractionResult.SUCCESS;
        if (player.isPassenger()) return InteractionResult.PASS;
        if (isFull()) return InteractionResult.PASS;
        player.startRiding(this, true);
        return InteractionResult.CONSUME;
    }

    @Override
    public double getPassengersRidingOffset() {
        return switch (type) {
            case CAR, TRUCK -> 0.75;
            case HELICOPTER -> 1.0;
            case AIRPLANE -> 0.9;
        };
    }

    @Override
    public void tick() {
        super.tick();
        idleTicks++;

        Entity controller = getControllingPassenger();
        if (controller instanceof Player player) {
            tickPlayerDriving(player);
        } else if (controller instanceof MercenaryEntity npc) {
            tickNpcDriving(npc);
        } else {
            tickUnoccupied();
        }

        moveSelf(getDeltaMovement());
    }

    private void tickPlayerDriving(Player player) {
        float forward = getPersistentData().getFloat("FCForward");
        float strafe = getPersistentData().getFloat("FCSide");
        float pitchInput = getPersistentData().getFloat("FCPitch");

        float yaw = player.getYRot();
        setYRot(yaw);
        setYRot(Mth.wrapDegrees(getYRot()));

        double speed = switch (type) {
            case CAR -> 0.55;
            case TRUCK -> 0.45;
            case HELICOPTER -> 0.75;
            case AIRPLANE -> 1.15;
        };

        Vec3 forwardVec = Vec3.directionFromRotation(0, yaw);
        Vec3 sideVec = Vec3.directionFromRotation(0, yaw + 90f);
        Vec3 move = forwardVec.scale(forward * speed).add(sideVec.scale(strafe * speed * 0.45));

        if (type == Type.CAR || type == Type.TRUCK) {
            move = new Vec3(move.x, getDeltaMovement().y, move.z);
            setXRot(0);
        } else if (type == Type.HELICOPTER) {
            move = move.add(0, pitchInput * 0.18, 0);
            setXRot(player.getXRot() * 0.35f);
        } else {
            double vertical = -player.getXRot() * 0.015 * speed;
            move = move.add(0, vertical, 0);
            setXRot(player.getXRot() * 0.45f);
        }

        setDeltaMovement(move);
    }

    private void tickNpcDriving(MercenaryEntity driver) {
        if (driver.isDownedOrCorpse() || !driver.isAlive()) {
            driver.stopRiding();
            setDeltaMovement(Vec3.ZERO);
            return;
        }

        net.minecraft.world.entity.LivingEntity target = driver.getTarget();
        Vec3 destination;

        if (target != null && target.isAlive() && !target.isRemoved()) {
            destination = target.position().add(0, desiredAltitude(target), 0);
        } else {
            destination = getCruiseDestination();
            if (destination == null) {
                destination = randomCruiseDestination(driver);
            }
        }

        Vec3 to = destination.subtract(position());
        double horizontal = Math.sqrt(to.x * to.x + to.z * to.z);
        double total = to.length();

        // Ground vehicles stop and deploy their driver into combat once they reach the target.
        if ((type == Type.CAR || type == Type.TRUCK) && target != null && horizontal < 8.0) {
            setDeltaMovement(getDeltaMovement().scale(0.35));
            driver.stopRiding();
            driver.getPersistentData().putInt("FCVehicleCooldown", 100);
            return;
        }

        if (target == null && total < 5.0) {
            clearCruiseDestination();
            setDeltaMovement(getDeltaMovement().scale(0.45));
            return;
        }

        float desiredYaw = (float)(Math.toDegrees(Math.atan2(-to.x, to.z)));
        float yawDiff = Mth.wrapDegrees(desiredYaw - getYRot());
        float turn = switch (type) {
            case CAR -> 5.5f;
            case TRUCK -> 4.0f;
            case HELICOPTER -> 4.5f;
            case AIRPLANE -> 2.8f;
        };
        setYRot(getYRot() + Mth.clamp(yawDiff, -turn, turn));

        double speed = switch (type) {
            case CAR -> 0.48;
            case TRUCK -> 0.40;
            case HELICOPTER -> 0.72;
            case AIRPLANE -> 1.00;
        };

        Vec3 forward = Vec3.directionFromRotation(0, getYRot());
        Vec3 move = forward.scale(speed);

        if (type == Type.CAR || type == Type.TRUCK) {
            move = new Vec3(move.x, getDeltaMovement().y, move.z);
            setXRot(0);
        } else {
            double vertical = Mth.clamp(to.y * 0.045, -0.22, 0.22);
            move = move.add(0, vertical, 0);
            setXRot(Mth.clamp((float)(-Math.toDegrees(Math.atan2(to.y, Math.max(0.001, horizontal)))) * 0.55f, -25f, 25f));
        }

        setDeltaMovement(move);
    }

    private double desiredAltitude(net.minecraft.world.entity.LivingEntity target) {
        return switch (type) {
            case HELICOPTER -> 7.0;
            case AIRPLANE -> 12.0;
            default -> 0.0;
        };
    }

    private Vec3 getCruiseDestination() {
        if (!getPersistentData().contains("CruiseX")) return null;
        return new Vec3(
            getPersistentData().getDouble("CruiseX"),
            getPersistentData().getDouble("CruiseY"),
            getPersistentData().getDouble("CruiseZ"));
    }

    private Vec3 randomCruiseDestination(MercenaryEntity driver) {
        java.util.Random r = new java.util.Random(getId() * 31L + tickCount * 17L);
        double radius = 18 + r.nextInt(34);
        double a = r.nextDouble() * Math.PI * 2.0;
        double y = switch (type) {
            case HELICOPTER -> getY() + 6;
            case AIRPLANE -> getY() + 10;
            default -> getY();
        };
        Vec3 destination = new Vec3(getX() + Math.cos(a) * radius, y, getZ() + Math.sin(a) * radius);
        getPersistentData().putDouble("CruiseX", destination.x);
        getPersistentData().putDouble("CruiseY", destination.y);
        getPersistentData().putDouble("CruiseZ", destination.z);
        return destination;
    }

    private void clearCruiseDestination() {
        getPersistentData().remove("CruiseX");
        getPersistentData().remove("CruiseY");
        getPersistentData().remove("CruiseZ");
    }

    private void tickUnoccupied() {
        double drag = switch (type) {
            case CAR, TRUCK -> 0.82;
            case HELICOPTER -> 0.96;
            case AIRPLANE -> 0.985;
        };
        setDeltaMovement(getDeltaMovement().scale(drag));
        if ((type == Type.HELICOPTER || type == Type.AIRPLANE) && !isOnGround()) {
            setDeltaMovement(getDeltaMovement().add(0,
                type == Type.HELICOPTER ? -0.01 : -0.004, 0));
        }
    }

    private void moveSelf(Vec3 motion) {
        double nx = getX() + motion.x;
        double ny = getY() + motion.y;
        double nz = getZ() + motion.z;

        if (type == Type.CAR || type == Type.TRUCK) {
            if (!getCommandSenderWorld().noCollision(this, getBoundingBox().move(motion.x, 0, motion.z))) {
                setDeltaMovement(0, getDeltaMovement().y, 0);
                return;
            }
            ny = getY();
        }
        setPos(nx, ny, nz);
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (isInvulnerableTo(source)) return false;
        health -= amount;
        if (health <= 0) {
            getCommandSenderWorld().explode(this, getX(), getY(), getZ(), 2.5f,
                net.minecraft.world.level.Level.ExplosionInteraction.TNT);
            for (Entity passenger : getPassengers()) passenger.stopRiding();
            discard();
        }
        return true;
    }
}
