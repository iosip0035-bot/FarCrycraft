package com.farcrycraft.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.UUID;

public class MercenaryEntity extends Monster {
    private static final EntityDataAccessor<Integer> AMMO = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> RESERVE = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> RELOADING = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DOWNED = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> TAKEDOWN = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> ALERT = SynchedEntityData.defineId(MercenaryEntity.class, EntityDataSerializers.BOOLEAN);

    private final String role;
    private int fireTimer;
    private int reloadTicks;
    private int alertTicks;
    private int searchTicks;
    private int coverCooldown;
    private int flankTicks;
    private int vehicleCheckCooldown;
    private Vec3 lastKnownTarget;
    private BlockPos coverPos;

    public MercenaryEntity(EntityType<? extends Monster> type, Level level, String role) {
        super(type, level);
        this.role = role;
        entityData.set(AMMO, magazineSize());
        entityData.set(RESERVE, reserveSize());
    }

    public String role() { return role; }
    public int getAmmoInMag() { return entityData.get(AMMO); }
    public int getReserveAmmo() { return entityData.get(RESERVE); }
    public boolean isReloading() { return entityData.get(RELOADING); }
    public boolean isDownedOrCorpse() { return entityData.get(DOWNED); }
    public boolean isTakedownActive() { return entityData.get(TAKEDOWN); }
    public boolean isAlert() { return entityData.get(ALERT); }

    private int magazineSize() {
        return switch (role) {
            case "machine_gunner" -> 75;
            case "sniper" -> 5;
            case "heavy" -> 45;
            default -> 30;
        };
    }

    private int reserveSize() {
        return switch (role) {
            case "machine_gunner" -> 225;
            case "sniper" -> 30;
            case "heavy" -> 180;
            default -> 150;
        };
    }

    private double preferredRange() {
        return switch (role) {
            case "sniper" -> 32.0;
            case "machine_gunner" -> 18.0;
            case "heavy" -> 12.0;
            default -> 16.0;
        };
    }

    private float accuracy() {
        return switch (role) {
            case "sniper" -> 0.015f;
            case "machine_gunner" -> 0.06f;
            case "heavy" -> 0.045f;
            default -> 0.035f;
        };
    }

    public static AttributeSupplier.Builder attributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH, 26)
            .add(Attributes.MOVEMENT_SPEED, .28)
            .add(Attributes.ATTACK_DAMAGE, 4)
            .add(Attributes.FOLLOW_RANGE, 48)
            .add(Attributes.KNOCKBACK_RESISTANCE, .15);
    }

    @Override protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(AMMO, 30);
        entityData.define(RESERVE, 150);
        entityData.define(RELOADING, false);
        entityData.define(DOWNED, false);
        entityData.define(TAKEDOWN, false);
        entityData.define(ALERT, false);
    }

    @Override public void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("EnemyAmmo", getAmmoInMag());
        tag.putInt("EnemyReserve", getReserveAmmo());
        tag.putBoolean("Downed", isDownedOrCorpse());
        tag.putBoolean("Alert", isAlert());
        if (lastKnownTarget != null) {
            tag.putDouble("LastX", lastKnownTarget.x);
            tag.putDouble("LastY", lastKnownTarget.y);
            tag.putDouble("LastZ", lastKnownTarget.z);
        }
    }

    @Override public void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(AMMO, tag.getInt("EnemyAmmo"));
        entityData.set(RESERVE, tag.getInt("EnemyReserve"));
        entityData.set(DOWNED, tag.getBoolean("Downed"));
        entityData.set(ALERT, tag.getBoolean("Alert"));
        if (tag.contains("LastX")) lastKnownTarget = new Vec3(tag.getDouble("LastX"), tag.getDouble("LastY"), tag.getDouble("LastZ"));
    }

    @Override protected void registerGoals() {
        goalSelector.addGoal(1, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, true));
        goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.0));
        goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 16));
        targetSelector.addGoal(1, new com.farcrycraft.common.StealthTargetGoal(this));
    }

    @Override public void aiStep() {
        super.aiStep();

        if (coverCooldown > 0) coverCooldown--;
        if (flankTicks > 0) flankTicks--;

        if (isDownedOrCorpse()) {
            setNoAi(true);
            setDeltaMovement(Vec3.ZERO);
            if (isTakedownActive()) {
                int ticks = getPersistentData().getInt("FC_TakedownTicks") - 1;
                getPersistentData().putInt("FC_TakedownTicks", ticks);
                if (ticks == 14) playSound(net.minecraft.sounds.SoundEvents.PLAYER_ATTACK_STRONG, .6f, .75f);
                if (ticks <= 0) {
                    entityData.set(TAKEDOWN, false);
                    getPersistentData().putBoolean("FC_Corpse", true);
                }
            }
            if (isPassenger()) stopRiding();
            return;
        }

        if (getCommandSenderWorld().isClientSide) return;

        if (vehicleCheckCooldown > 0) vehicleCheckCooldown--;

        // NPC vehicle behavior: board military vehicles when far from the player,
        // pursue targets with a vehicle, and use non-driver seats as gunners.
        if (isPassenger() && getVehicle() instanceof FarCryVehicleEntity) {
            tickVehiclePassenger();
            return;
        }

        LivingEntity mountedTarget = getTarget();
        if (!isPassenger() && vehicleCheckCooldown == 0 && canUseVehicles()) {
            tryBoardMilitaryVehicle(mountedTarget);
            if (isPassenger()) return;
            vehicleCheckCooldown = 40;
        }

        LivingEntity target = getTarget();
        if (target instanceof Player hiddenPlayer && com.farcrycraft.common.StealthSystem.isHiddenFrom(this, hiddenPlayer)) {
            setTarget(null);
            target = null;
        }

        // Hear/search for gunfire even if the soldier never saw the shooter.
        if (target == null && searchTicks > 0 && lastKnownTarget != null) {
            searchTicks--;
            getNavigation().moveTo(lastKnownTarget.x, lastKnownTarget.y, lastKnownTarget.z, 1.1);
            getLookControl().setLookAt(lastKnownTarget.x, lastKnownTarget.y, lastKnownTarget.z);
            if (searchTicks == 0) entityData.set(ALERT, false);
            return;
        }

        if (target != null) {
            if (hasLineOfSight(target)) {
                lastKnownTarget = target.position().add(0, target.getBbHeight() * .5, 0);
                searchTicks = 100;
                alertTicks = 120;
                entityData.set(ALERT, true);
                shareTarget(target);
            } else if (lastKnownTarget != null && searchTicks > 0) {
                getNavigation().moveTo(lastKnownTarget.x, lastKnownTarget.y, lastKnownTarget.z, 1.05);
            }
        }

        if (alertTicks > 0) alertTicks--;
        if (alertTicks == 0 && target == null) entityData.set(ALERT, false);

        if (reloadTicks > 0) {
            // Reload in cover whenever possible.
            if (target != null && coverPos == null && coverCooldown <= 0) chooseCover(target);
            if (coverPos != null) moveToCover();
            reloadTicks--;
            if (reloadTicks == 0) finishReload();
            return;
        }

        if (target == null) return;

        double distance = distanceTo(target);
        if (healthRatio() < .38f && coverCooldown <= 0) chooseCover(target);
        if (coverPos != null && !isSafeEnough(target)) {
            moveToCover();
            if (distance > preferredRange() + 8) getNavigation().moveTo(target, 1.1);
            return;
        }

        getLookControl().setLookAt(target, 40, 40);

        // Smart positioning: snipers keep distance, close-range soldiers circle.
        if (distance < preferredRange() - 5) {
            Vec3 away = position().subtract(target.position()).normalize();
            BlockPos retreat = blockPosition().offset((int)Math.round(away.x * 4), 0, (int)Math.round(away.z * 4));
            getNavigation().moveTo(retreat.getX(), retreat.getY(), retreat.getZ(), 1.15);
        } else if (distance > preferredRange() + 12) {
            getNavigation().moveTo(target, 1.15);
        } else if (flankTicks == 0 && role.equals("heavy") == false) {
            // Short strafing bursts make the AI harder to hit without teleporting.
            double side = ((getId() & 1) == 0) ? 1 : -1;
            Vec3 perpendicular = new Vec3(-getLookAngle().z, 0, getLookAngle().x).normalize().scale(side * 2.0);
            getNavigation().moveTo(getX() + perpendicular.x, getY(), getZ() + perpendicular.z, .95);
            flankTicks = 35;
        }

        int rate = switch (role) {
            case "sniper" -> 40;
            case "machine_gunner" -> 4;
            case "heavy" -> 9;
            default -> 13;
        };

        if (++fireTimer >= rate) {
            fireTimer = 0;
            if (getAmmoInMag() <= 0) startReload();
            else shoot(target);
        }
    }

    private boolean canUseVehicles() {
        if (getPersistentData().contains("FC_CanUseVehicles"))
            return getPersistentData().getBoolean("FC_CanUseVehicles");
        return getPersistentData().getBoolean("FC_Military") ||
            role.equals("driver") || role.equals("pilot") || role.equals("mercenary") ||
            role.equals("heavy") || role.equals("machine_gunner");
    }

    private void tryBoardMilitaryVehicle(LivingEntity target) {
        double maxDistance = target != null ? 22.0 : 10.0;
        if (target != null && distanceTo(target) < 14.0) return;

        FarCryVehicleEntity best = null;
        double bestDistance = maxDistance * maxDistance;
        for (FarCryVehicleEntity vehicle : getCommandSenderWorld().getEntitiesOfClass(
            FarCryVehicleEntity.class, getBoundingBox().inflate(maxDistance),
            v -> v.getPersistentData().getBoolean("FC_MilitaryVehicle") && !v.isFull())) {

            boolean aircraft = vehicle.getVehicleType() == FarCryVehicleEntity.Type.HELICOPTER ||
                vehicle.getVehicleType() == FarCryVehicleEntity.Type.AIRPLANE;
            boolean pilot = role.equals("pilot") || getPersistentData().getBoolean("FC_Pilot");
            if (aircraft && vehicle.getPassengers().isEmpty() && !pilot) continue;

            double d = distanceToSqr(vehicle);
            if (d < bestDistance) {
                bestDistance = d;
                best = vehicle;
            }
        }

        if (best != null) {
            startRiding(best, true);
            getPersistentData().putBoolean("FC_OnMilitaryVehicle", true);
        }
    }

    private void tickVehiclePassenger() {
        if (!(getVehicle() instanceof FarCryVehicleEntity vehicle)) return;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || StealthSystem.isHiddenFrom(this, target)) return;
        if (!hasLineOfSight(target) || distanceTo(target) > 48) return;

        int rate = switch (role) {
            case "sniper" -> 46;
            case "machine_gunner" -> 5;
            case "heavy" -> 11;
            default -> 15;
        };
        if (++fireTimer >= rate && !isReloading()) {
            fireTimer = 0;
            if (getAmmoInMag() <= 0) startReload();
            else shoot(target);
        }
    }

    private float healthRatio() { return getHealth() / getMaxHealth(); }

    private void shareTarget(LivingEntity target) {
        if (!(getCommandSenderWorld() instanceof ServerLevel level)) return;
        List<MercenaryEntity> allies = level.getEntitiesOfClass(MercenaryEntity.class, getBoundingBox().inflate(24));
        for (MercenaryEntity ally : allies) {
            if (ally == this || ally.isDownedOrCorpse()) continue;
            if (ally.getTarget() == null) ally.setTarget(target);
            ally.alertTicks = Math.max(ally.alertTicks, 60);
            ally.searchTicks = Math.max(ally.searchTicks, 60);
            ally.lastKnownTarget = target.position();
            ally.entityData.set(ALERT, true);
        }
    }

    private void chooseCover(LivingEntity target) {
        if (coverCooldown > 0) return;
        coverCooldown = 70;
        BlockPos origin = blockPosition();
        double bestScore = -Double.MAX_VALUE;
        BlockPos best = null;

        for (int i = 0; i < 18; i++) {
            double a = (Math.PI * 2 * i) / 18.0;
            int r = 3 + (i % 4);
            BlockPos candidate = origin.offset((int)Math.round(Math.cos(a) * r), 0, (int)Math.round(Math.sin(a) * r));
            if (!getCommandSenderWorld().getBlockState(candidate.below()).isSolidRender(getCommandSenderWorld(), candidate.below())) continue;
            if (!getCommandSenderWorld().getBlockState(candidate).isAir()) continue;

            Vec3 eye = new Vec3(candidate.getX()+.5, candidate.getY()+1.6, candidate.getZ()+.5);
            boolean blocked = getCommandSenderWorld().clip(new net.minecraft.world.level.ClipContext(
                eye, target.getEyePosition(),
                net.minecraft.world.level.ClipContext.Block.COLLIDER,
                net.minecraft.world.level.ClipContext.Fluid.NONE, this
            )).getType() != net.minecraft.world.phys.HitResult.Type.MISS;

            double d = candidate.distSqr(blockPosition());
            double score = (blocked ? 45 : -20) - d;
            if (Vec3.atCenterOf(candidate).distanceToSqr(target.position()) < 324.0) score -= 10;
            if (score > bestScore) { bestScore = score; best = candidate; }
        }
        coverPos = best;
    }

    private boolean isSafeEnough(LivingEntity target) {
        if (coverPos == null) return false;
        Vec3 eye = Vec3.atCenterOf(coverPos).add(0, 1.4, 0);
        return getCommandSenderWorld().clip(new net.minecraft.world.level.ClipContext(
            eye, target.getEyePosition(),
            net.minecraft.world.level.ClipContext.Block.COLLIDER,
            net.minecraft.world.level.ClipContext.Fluid.NONE, this
        )).getType() != net.minecraft.world.phys.HitResult.Type.MISS;
    }

    private void moveToCover() {
        if (coverPos == null) return;
        getNavigation().moveTo(coverPos.getX()+.5, coverPos.getY(), coverPos.getZ()+.5, 1.25);
        if (distanceToSqr(coverPos.getX()+.5, coverPos.getY(), coverPos.getZ()+.5) < 3.0)
            getNavigation().stop();
    }

    public void hearGunshot(Vec3 position, Player shooter) {
        if (isDownedOrCorpse()) return;
        double max = role.equals("sniper") ? 64 : 48;
        if (distanceToSqr(position) > max * max) return;
        lastKnownTarget = position;
        searchTicks = Math.max(searchTicks, 100);
        alertTicks = Math.max(alertTicks, 120);
        entityData.set(ALERT, true);
        if (getTarget() == null && hasLineOfSight(shooter)) setTarget(shooter);
    }

    private void startReload() {
        if (getReserveAmmo() <= 0 || isReloading()) return;
        reloadTicks = role.equals("machine_gunner") ? 70 : role.equals("sniper") ? 52 : 40;
        entityData.set(RELOADING, true);
        getPersistentData().putInt("FCReloadAnimTicks", reloadTicks);
        LivingEntity target = getTarget();
        if (target != null) chooseCover(target);
    }

    private void finishReload() {
        int take = Math.min(magazineSize() - getAmmoInMag(), getReserveAmmo());
        entityData.set(AMMO, getAmmoInMag() + take);
        entityData.set(RESERVE, getReserveAmmo() - take);
        entityData.set(RELOADING, false);
        coverPos = null;
    }

    private void shoot(LivingEntity target) {
        if (getAmmoInMag() <= 0) { startReload(); return; }
        entityData.set(AMMO, getAmmoInMag() - 1);

        Vec3 start = getEyePosition();
        Vec3 base = target.getEyePosition().subtract(start).normalize();
        net.minecraft.util.RandomSource r = getRandom();
        Vec3 dir = new Vec3(
            base.x + r.nextGaussian() * accuracy(),
            base.y + r.nextGaussian() * accuracy(),
            base.z + r.nextGaussian() * accuracy()
        ).normalize();
        Vec3 end = start.add(dir.scale(48));

        if (getCommandSenderWorld().clip(new net.minecraft.world.level.ClipContext(
            start, end,
            net.minecraft.world.level.ClipContext.Block.COLLIDER,
            net.minecraft.world.level.ClipContext.Fluid.NONE, this
        )).getType() == net.minecraft.world.phys.HitResult.Type.MISS) {
            float damage = switch (role) {
                case "sniper" -> 11f;
                case "machine_gunner" -> 3f;
                case "heavy" -> 6f;
                default -> 4.5f;
            };
            target.hurt(getCommandSenderWorld().getDamageSources().mobAttack(this), damage);
        }
    }

    public void startMacheteTakedown() {
        if (isDownedOrCorpse() || isTakedownActive()) return;
        entityData.set(DOWNED, true);
        entityData.set(TAKEDOWN, true);
        entityData.set(RELOADING, false);
        getPersistentData().putInt("FC_TakedownTicks", 20);
        setNoAi(true);
        setDeltaMovement(Vec3.ZERO);
        setHealth(1f);
        reloadTicks = 0;
    }

    public void setDraggedBy(UUID player) {
        getPersistentData().putUUID("FC_DraggedBy", player);
        setNoAi(true);
    }
    public void clearDraggedBy() { getPersistentData().remove("FC_DraggedBy"); }
    public boolean isDragged() { return getPersistentData().hasUUID("FC_DraggedBy"); }

    @Override public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        if (isDownedOrCorpse()) return false;
        if (role.equals("heavy")) amount *= .55f;
        return super.hurt(source, amount);
    }
}
