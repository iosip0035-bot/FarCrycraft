package com.farcrycraft.common;

import com.farcrycraft.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

public class StealthBushSystem {
    @SubscribeEvent
    public void tick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.level.isClientSide) return;
        if (!(event.level instanceof ServerLevel level)) return;
        if (level.getGameTime() % 1200 != 0) return;

        for (Player player : level.players()) {
            Random random = new Random(level.getSeed() ^ player.blockPosition().asLong() ^ level.getGameTime());
            int patches = 1;
            for (int patch = 0; patch < patches; patch++) {
                int centerX = player.getBlockX() + random.nextInt(61) - 30;
                int centerZ = player.getBlockZ() + random.nextInt(61) - 30;
                BlockPos center = level.getHeightmapPos(
                    Heightmap.Types.WORLD_SURFACE, new BlockPos(centerX, 0, centerZ));

                for (int i = 0; i < 4 + random.nextInt(5); i++) {
                    int x = center.getX() + random.nextInt(7) - 3;
                    int z = center.getZ() + random.nextInt(7) - 3;
                    BlockPos pos = level.getHeightmapPos(
                        Heightmap.Types.WORLD_SURFACE, new BlockPos(x, 0, z));
                    BlockState current = level.getBlockState(pos);
                    BlockState below = level.getBlockState(pos.below());
                    if (current.isAir() && below.isSolidRender(level, pos.below())) {
                        level.setBlock(pos, ModBlocks.STEALTH_BUSH.get().defaultBlockState(), 3);
                    }
                }
            }
        }
    }
}
