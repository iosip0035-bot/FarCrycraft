package com.farcrycraft.common;

import com.farcrycraft.entity.MercenaryEntity;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;

public class StealthTargetGoal extends NearestAttackableTargetGoal<Player> {
    private final MercenaryEntity owner;

    public StealthTargetGoal(MercenaryEntity owner) {
        super(owner, Player.class, true);
        this.owner = owner;
    }

    @Override
    public boolean canUse() {
        if (!super.canUse()) return false;
        if (owner.getTarget() instanceof Player player && StealthSystem.isHiddenFrom(owner, player)) {
            owner.setTarget(null);
            return false;
        }
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (!super.canContinueToUse()) return false;
        if (owner.getTarget() instanceof Player player && StealthSystem.isHiddenFrom(owner, player)) {
            owner.setTarget(null);
            return false;
        }
        return true;
    }
}
