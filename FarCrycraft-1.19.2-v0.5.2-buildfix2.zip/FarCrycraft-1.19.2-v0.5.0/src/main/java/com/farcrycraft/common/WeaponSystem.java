package com.farcrycraft.common;
import com.farcrycraft.item.*;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.*;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.*;
import java.util.Random;
public final class WeaponSystem {
 public static void fire(Player p,ItemStack s,WeaponSpecs.Spec sp){
  if(p.getCooldowns().isOnCooldown(s.getItem()))return;
  WeaponItem.init(s,sp);var n=s.getOrCreateTag();int a=n.getInt("Ammo");
  if(a<=0){p.playSound(SoundEvents.PISTON_EXTEND,.2f,1.7f);return;}n.putInt("Ammo",a-1);p.getCooldowns().addCooldown(s.getItem(),sp.cooldown());
  com.farcrycraft.common.StealthSystem.breakStealth(p, 80);
  if(p.getCommandSenderWorld() instanceof net.minecraft.server.level.ServerLevel slSound){
   for(com.farcrycraft.entity.MercenaryEntity enemy : slSound.getEntitiesOfClass(com.farcrycraft.entity.MercenaryEntity.class, p.getBoundingBox().inflate(48), e -> e.isAlive() && !e.isDownedOrCorpse())) enemy.hearGunshot(p.position(), p);
  }
  Random r=new Random();for(int i=0;i<sp.pellets();i++){
   Vec3 start=p.getEyePosition(),base=p.getViewVector(1);double spread=sp.spread();
   Vec3 dir=new Vec3(base.x+r.nextGaussian()*spread,base.y+r.nextGaussian()*spread,base.z+r.nextGaussian()*spread).normalize();Vec3 end=start.add(dir.scale(sp.range()));
   HitResult wall=p.getCommandSenderWorld().clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p));double max=sp.range();if(wall.getType()!=HitResult.Type.MISS)max=start.distanceTo(wall.getLocation());
   Entity hit=null;double best=max;AABB scan=p.getBoundingBox().expandTowards(dir.scale(max)).inflate(1);
   for(Entity e:p.getCommandSenderWorld().getEntities(p,scan,e->e instanceof LivingEntity&&e.isAlive())){var c=e.getBoundingBox().inflate(.1).clip(start,end);if(c.isPresent()){double d=start.distanceTo(c.get());if(d<best){best=d;hit=e;}}}
   if(hit instanceof LivingEntity living){float fall=Mth.clamp(1f-(float)(best/sp.range())*.65f,.35f,1f);Vec3 impact=start.add(dir.scale(best));boolean head=impact.y>living.getY()+living.getBbHeight()*.78;float dmg=sp.damage()*fall*(head?2f:1f);if(sp.id().equals("rpg"))p.getCommandSenderWorld().explode(p,impact.x,impact.y,impact.z,4f,net.minecraft.world.level.Level.ExplosionInteraction.TNT);else living.hurt(p.getCommandSenderWorld().getDamageSources().playerAttack(p),dmg);}
   if(p.getCommandSenderWorld() instanceof net.minecraft.server.level.ServerLevel sl)sl.sendParticles(ParticleTypes.SMOKE,end.x,end.y,end.z,1,0,0,0,.01);
  }
  p.getCommandSenderWorld().playSound(null,p.blockPosition(),SoundEvents.GENERIC_EXPLODE,SoundSource.PLAYERS,.12f,1.8f);
 }
 private WeaponSystem(){}
}
