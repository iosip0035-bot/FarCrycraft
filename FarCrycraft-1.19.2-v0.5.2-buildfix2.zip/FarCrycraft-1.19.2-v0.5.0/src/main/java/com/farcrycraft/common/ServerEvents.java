package com.farcrycraft.common;

import com.farcrycraft.item.WeaponItem;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ServerEvents {
    @SubscribeEvent public void playerTick(TickEvent.PlayerTickEvent e){
        if(e.phase!=TickEvent.Phase.END||e.player.getCommandSenderWorld().isClientSide)return;
        var p=e.player;
        if (p.getPersistentData().getInt("FC_ReloadTicks") > 0) {
            int ticks = p.getPersistentData().getInt("FC_ReloadTicks") - 1;
            if (ticks <= 0) {
                p.getPersistentData().remove("FC_ReloadTicks");
                if (p.getMainHandItem().getItem() instanceof WeaponItem w) {
                    WeaponItem.init(p.getMainHandItem(), w.spec());
                    var tag = p.getMainHandItem().getOrCreateTag();
                    int have = tag.getInt("Ammo"), reserve = tag.getInt("Reserve");
                    int take = Math.min(w.spec().mag() - have, reserve);
                    tag.putInt("Ammo", have + take);
                    tag.putInt("Reserve", reserve - take);
                }
            } else {
                p.getPersistentData().putInt("FC_ReloadTicks", ticks);
            }
        }
        if(p.getPersistentData().getBoolean("FCParachute")&&!p.isOnGround()){
            p.setDeltaMovement(p.getDeltaMovement().multiply(.90,.19,.90)); p.fallDistance=0;
            p.getPersistentData().putBoolean("FCParachuteOpen",true);
        } else if(p.isOnGround()) { p.getPersistentData().putBoolean("FCParachute",false); p.getPersistentData().putBoolean("FCParachuteOpen",false); }
        if(p.getMainHandItem().getItem() instanceof WeaponItem w) WeaponItem.init(p.getMainHandItem(),w.spec());
    }
    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e){
        e.getEntity().getPersistentData().putInt("FCReserveBonus",0);
    }
}
