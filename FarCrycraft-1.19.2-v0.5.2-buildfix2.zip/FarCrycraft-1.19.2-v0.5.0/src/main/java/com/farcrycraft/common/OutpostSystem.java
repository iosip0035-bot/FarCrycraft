package com.farcrycraft.common;

import com.farcrycraft.entity.FarCryVehicleEntity;
import com.farcrycraft.entity.MercenaryEntity;
import com.farcrycraft.registry.ModEntities;
import com.farcrycraft.registry.ModItems;
import com.farcrycraft.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.*;

public class OutpostSystem {
    private final Set<Long> generatedCells = new HashSet<>();
    private final List<MilitarySite> sites = new ArrayList<>();

    private enum SiteType { CHECKPOINT, MILITARY_BASE, AIRFIELD }

    private static final class MilitarySite {
        final BlockPos center;
        final SiteType type;
        final int radius;
        boolean alarmed;
        long alarmTick;
        long lastReinforcement;
        MilitarySite(BlockPos center, SiteType type, int radius) {
            this.center = center; this.type = type; this.radius = radius;
        }
    }

    @SubscribeEvent
    public void tick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.level.isClientSide || !(e.level instanceof ServerLevel level)) return;

        if (level.getGameTime() % 600 == 0) discoverAndGenerate(level);
        if (level.getGameTime() % 10 == 0) updateSites(level);
    }

    private void discoverAndGenerate(ServerLevel level) {
        for (Player player : level.players()) {
            long cell = cellKey(player.blockPosition());
            if (generatedCells.contains(cell)) continue;

            Random random = new Random(level.getSeed() ^ cell * 0x9E3779B97F4A7C15L);
            if (random.nextInt(3) != 0) continue;

            int dx = random.nextInt(241) - 120;
            int dz = random.nextInt(241) - 120;
            BlockPos origin = level.getHeightmapPos(
                Heightmap.Types.WORLD_SURFACE,
                player.blockPosition().offset(dx, 0, dz));

            SiteType type = SiteType.values()[random.nextInt(SiteType.values().length)];
            int radius = type == SiteType.CHECKPOINT ? 10 : type == SiteType.MILITARY_BASE ? 18 : 26;
            if (!safeForSite(level, origin, radius)) continue;

            generate(level, origin, type, radius, random);
            sites.add(new MilitarySite(origin, type, radius));
            generatedCells.add(cell);
        }
    }

    private boolean safeForSite(ServerLevel level, BlockPos c, int radius) {
        if (c.getY() < level.getMinBuildHeight() + 5 || c.getY() > level.getMaxBuildHeight() - 20) return false;
        return level.getBlockState(c.below()).isSolidRender(level, c.below()) && level.getFluidState(c).isEmpty();
    }

    private void generate(ServerLevel level, BlockPos c, SiteType type, int radius, Random r) {
        // Perimeter
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                boolean edge = Math.abs(x) == radius || Math.abs(z) == radius;
                if (edge) {
                    level.setBlock(c.offset(x, 0, z), wallFor(type), 3);
                    if (Math.abs(x) % 3 == 0 || Math.abs(z) % 3 == 0)
                        level.setBlock(c.offset(x, 1, z), Blocks.IRON_BARS.defaultBlockState(), 3);
                } else if (type != SiteType.CHECKPOINT) {
                    level.setBlock(c.offset(x, 0, z), Blocks.SMOOTH_STONE.defaultBlockState(), 3);
                }
            }
        }

        // Main gate and command building
        buildGate(level, c, radius, type);
        buildBuilding(level, c.offset(-4, 1, -4), 8, 6, type == SiteType.AIRFIELD ? Blocks.IRON_BLOCK : Blocks.STONE_BRICKS);
        placeLootChest(level, c.offset(0, 1, 5), r);

        // Watchtowers + alarm
        int towers = type == SiteType.CHECKPOINT ? 0 : type == SiteType.MILITARY_BASE ? 4 : 6;
        for (int i = 0; i < towers; i++) {
            double a = (Math.PI * 2 * i) / towers;
            int x = c.getX() + (int)(Math.cos(a) * (radius - 2));
            int z = c.getZ() + (int)(Math.sin(a) * (radius - 2));
            buildTower(level, new BlockPos(x, c.getY(), z));
        }
        level.setBlock(c.above(), Blocks.BELL.defaultBlockState(), 3);

        // Defensive props / crates
        for (int i = 0; i < (type == SiteType.AIRFIELD ? 10 : 6); i++) {
            int x = c.getX() + r.nextInt(radius * 2 - 3) - (radius - 2);
            int z = c.getZ() + r.nextInt(radius * 2 - 3) - (radius - 2);
            level.setBlock(new BlockPos(x, c.getY() + 1, z),
                (i % 2 == 0 ? Blocks.BARREL : Blocks.CHEST).defaultBlockState(), 3);
        }

        addBushPerimeter(level, c, radius, r);

        // Vehicles: airfields get aircraft and helis, normal bases get ground vehicles.
        if (type == SiteType.AIRFIELD) {
            spawnVehicle(level, c.offset(-12, 1, 10), FarCryVehicleEntity.Type.AIRPLANE);
            spawnVehicle(level, c.offset(12, 1, 10), FarCryVehicleEntity.Type.HELICOPTER);
            spawnVehicle(level, c.offset(0, 1, 16), FarCryVehicleEntity.Type.TRUCK);
        } else if (type == SiteType.MILITARY_BASE) {
            spawnVehicle(level, c.offset(-10, 1, radius - 4), FarCryVehicleEntity.Type.TRUCK);
            spawnVehicle(level, c.offset(10, 1, radius - 4), FarCryVehicleEntity.Type.CAR);
        } else {
            spawnVehicle(level, c.offset(0, 1, radius + 2), FarCryVehicleEntity.Type.TRUCK);
        }

        // Defenders by role. They spawn around key positions, not all in one spot.
        int defenders = type == SiteType.CHECKPOINT ? 5 : type == SiteType.MILITARY_BASE ? 11 : 15;
        for (int i = 0; i < defenders; i++) {
            String role = pickRole(type, r, i);
            var typeObj = switch (role) {
                case "heavy" -> ModEntities.HEAVY.get();
                case "sniper" -> ModEntities.SNIPER.get();
                case "machine_gunner" -> ModEntities.MG.get();
                default -> ModEntities.MERCENARY.get();
            };
            MercenaryEntity mob = new MercenaryEntity(typeObj, level, role);
            double a = r.nextDouble() * Math.PI * 2;
            double d = 4 + r.nextDouble() * (radius - 7);
            mob.moveTo(c.getX() + Math.cos(a) * d,
                c.getY() + 1,
                c.getZ() + Math.sin(a) * d,
                r.nextFloat() * 360f, 0);
            mob.getPersistentData().putLong("FC_OutpostX", c.getX());
            mob.getPersistentData().putLong("FC_OutpostZ", c.getZ());
            mob.getPersistentData().putBoolean("FC_Military", true);
            level.addFreshEntity(mob);
        }
    }


    private void addBushPerimeter(ServerLevel level, BlockPos c, int radius, Random r) {
        for (int i = 0; i < radius * 2; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            double d = radius + 2 + r.nextInt(6);
            int x = c.getX() + (int)(Math.cos(a) * d);
            int z = c.getZ() + (int)(Math.sin(a) * d);
            BlockPos pos = level.getHeightmapPos(Heightmap.Types.WORLD_SURFACE, new BlockPos(x, 0, z));
            if (level.getBlockState(pos).isAir() && level.getBlockState(pos.below()).isSolidRender(level, pos.below())) {
                level.setBlock(pos, ModBlocks.STEALTH_BUSH.get().defaultBlockState(), 3);
            }
        }
    }

    private net.minecraft.world.level.block.state.BlockState wallFor(SiteType type) {
        return (type == SiteType.CHECKPOINT ? Blocks.COBBLESTONE : Blocks.STONE_BRICKS).defaultBlockState();
    }

    private String pickRole(SiteType type, Random r, int index) {
        if (type == SiteType.AIRFIELD && index % 5 == 0) return "sniper";
        if (index % 7 == 0) return "heavy";
        if (index % 4 == 0) return "machine_gunner";
        if (type == SiteType.MILITARY_BASE && index % 6 == 0) return "sniper";
        return "mercenary";
    }

    private void buildGate(ServerLevel level, BlockPos c, int radius, SiteType type) {
        for (int y = 0; y <= 2; y++) {
            level.setBlock(c.offset(-2, y, radius), Blocks.IRON_BLOCK.defaultBlockState(), 3);
            level.setBlock(c.offset(2, y, radius), Blocks.IRON_BLOCK.defaultBlockState(), 3);
        }
        for (int x = -2; x <= 2; x++)
            level.setBlock(c.offset(x, 3, radius), Blocks.IRON_BARS.defaultBlockState(), 3);
        level.setBlock(c.offset(0, 0, radius), Blocks.IRON_TRAPDOOR.defaultBlockState(), 3);
    }

    private void buildBuilding(ServerLevel level, BlockPos start, int width, int depth, Block block) {
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                boolean shell = x == 0 || z == 0 || x == width - 1 || z == depth - 1;
                for (int y = 0; y < 4; y++) {
                    if (shell || y == 3) level.setBlock(start.offset(x, y, z), block.defaultBlockState(), 3);
                }
            }
        }
        level.setBlock(start.offset(width / 2, 0, 0), Blocks.AIR.defaultBlockState(), 3);
    }

    private void buildTower(ServerLevel level, BlockPos base) {
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++)
            for (int y = 0; y <= 5; y++)
                if (Math.abs(x) == 1 || Math.abs(z) == 1)
                    level.setBlock(base.offset(x, y, z), Blocks.OAK_PLANKS.defaultBlockState(), 3);
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++)
            level.setBlock(base.offset(x, 6, z), Blocks.OAK_SLAB.defaultBlockState(), 3);
        level.setBlock(base.offset(0, 6, 0), Blocks.LANTERN.defaultBlockState(), 3);
    }

    private void placeLootChest(ServerLevel level, BlockPos pos, Random r) {
        level.setBlock(pos, Blocks.CHEST.defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof ChestBlockEntity chest) {
            chest.setItem(0, new ItemStack(ModItems.RIFLE_AMMO.get(), 8 + r.nextInt(10)));
            chest.setItem(1, new ItemStack(ModItems.PISTOL_AMMO.get(), 8 + r.nextInt(10)));
            chest.setItem(2, new ItemStack(ModItems.FRAG.get(), 1 + r.nextInt(2)));
            chest.setItem(3, new ItemStack(ModItems.MEDKIT.get(), 1 + r.nextInt(2)));
            chest.setChanged();
        }
    }

    private void spawnVehicle(ServerLevel level, BlockPos pos, FarCryVehicleEntity.Type type) {
        FarCryVehicleEntity vehicle = new FarCryVehicleEntity(ModEntities.VEHICLE.get(), level);
        vehicle.setType(type);
        vehicle.setPos(pos.getX() + .5, pos.getY() + .15, pos.getZ() + .5);
        vehicle.getPersistentData().putBoolean("FC_MilitaryVehicle", true);
        level.addFreshEntity(vehicle);

        // Military vehicles spawn with an actual AI crew. The first NPC becomes
        // the driver/pilot because the vehicle's first passenger is its controller.
        String driverRole = (type == FarCryVehicleEntity.Type.HELICOPTER ||
            type == FarCryVehicleEntity.Type.AIRPLANE) ? "pilot" : "driver";
        var driverType = driverRole.equals("pilot") ? ModEntities.MERCENARY.get() : ModEntities.MERCENARY.get();
        MercenaryEntity driver = new MercenaryEntity(driverType, level, driverRole);
        driver.moveTo(pos.getX() + .5, pos.getY() + 1, pos.getZ() + .5, 0, 0);
        driver.getPersistentData().putBoolean("FC_Military", true);
        driver.getPersistentData().putBoolean("FC_CanUseVehicles", true);
        driver.getPersistentData().putBoolean("FC_Pilot", driverRole.equals("pilot"));
        driver.getPersistentData().putBoolean("FC_VehicleCrew", true);
        level.addFreshEntity(driver);
        driver.startRiding(vehicle, true);

        // Trucks and helicopters can carry a second AI gunner.
        if (type == FarCryVehicleEntity.Type.TRUCK || type == FarCryVehicleEntity.Type.HELICOPTER) {
            MercenaryEntity gunner = new MercenaryEntity(ModEntities.MG.get(), level, "machine_gunner");
            gunner.moveTo(pos.getX() + .5, pos.getY() + 1, pos.getZ() + .5, 0, 0);
            gunner.getPersistentData().putBoolean("FC_Military", true);
            gunner.getPersistentData().putBoolean("FC_CanUseVehicles", false);
            gunner.getPersistentData().putBoolean("FC_VehicleCrew", true);
            level.addFreshEntity(gunner);
            gunner.startRiding(vehicle, true);
        }
    }

    private void updateSites(ServerLevel level) {
        long now = level.getGameTime();
        for (MilitarySite site : sites) {
            List<Player> players = new java.util.ArrayList<>();
            for (net.minecraft.server.level.ServerPlayer sp : level.players()) {
                if (sp.distanceToSqr(Vec3.atCenterOf(site.center)) < (site.radius + 16) * (site.radius + 16)) players.add(sp);
            }
            if (players.isEmpty()) continue;

            List<MercenaryEntity> defenders = level.getEntitiesOfClass(MercenaryEntity.class,
                new net.minecraft.world.phys.AABB(site.center).inflate(site.radius + 12),
                m -> m.getPersistentData().getBoolean("FC_Military"));

            for (Player p : players) {
                boolean seen = defenders.stream().anyMatch(d -> !d.isDownedOrCorpse() && !StealthSystem.isHiddenFrom(d, p) && d.hasLineOfSight(p) && d.distanceTo(p) < 34);
                if (seen && !site.alarmed) {
                    site.alarmed = true;
                    site.alarmTick = now;
                }
            }

            if (site.alarmed && now - site.lastReinforcement > 160) {
                site.lastReinforcement = now;
                int cap = site.type == SiteType.CHECKPOINT ? 7 : site.type == SiteType.MILITARY_BASE ? 16 : 22;
                if (defenders.size() < cap) {
                    Player target = players.get(0);
                    BlockPos reinf = edgeSpawn(site, target.blockPosition());
                    String role = now % 320 == 0 ? "heavy" : "mercenary";
                    var typeObj = role.equals("heavy") ? ModEntities.HEAVY.get() : ModEntities.MERCENARY.get();
                    MercenaryEntity m = new MercenaryEntity(typeObj, level, role);
                    m.moveTo(reinf.getX()+.5, reinf.getY()+1, reinf.getZ()+.5, target.getYRot(), 0);
                    m.getPersistentData().putBoolean("FC_Military", true);
                    level.addFreshEntity(m);
                }
            }

            // When all defenders are gone, the post is considered cleared.
            if (site.alarmed && defenders.stream().noneMatch(d -> d.isAlive() && !d.isDownedOrCorpse())) {
                site.alarmed = false;
            }
        }
    }

    private BlockPos edgeSpawn(MilitarySite site, BlockPos target) {
        int dx = target.getX() - site.center.getX();
        int dz = target.getZ() - site.center.getZ();
        if (Math.abs(dx) > Math.abs(dz))
            return site.center.offset(dx > 0 ? site.radius + 8 : -site.radius - 8, 0, 0);
        return site.center.offset(0, 0, dz > 0 ? site.radius + 8 : -site.radius - 8);
    }

    private long cellKey(BlockPos p) {
        return (((long)(p.getX() >> 7)) << 32) ^ ((p.getZ() >> 7) & 0xffffffffL);
    }
}
