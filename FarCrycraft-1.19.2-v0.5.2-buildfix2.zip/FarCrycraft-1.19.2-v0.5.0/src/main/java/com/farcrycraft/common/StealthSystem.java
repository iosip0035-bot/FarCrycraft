package com.farcrycraft.common;

import com.farcrycraft.block.StealthBushBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public final class StealthSystem {
    public static final String STEALTH_BROKEN_UNTIL = "FC_StealthBrokenUntil";

    private StealthSystem() {}

    public static boolean isInBush(Player player) {
        if (!player.isCrouching() || player.isSprinting()) return false;
        Level level = player.getCommandSenderWorld();
        BlockPos base = player.blockPosition();
        for (int x = -1; x <= 1; x++) {
            for (int y = 0; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    Block block = level.getBlockState(base.offset(x, y, z)).getBlock();
                    if (block instanceof StealthBushBlock) return true;
                }
            }
        }
        return false;
    }

    public static boolean isHidden(Player player) {
        long until = player.getPersistentData().getLong(STEALTH_BROKEN_UNTIL);
        return isInBush(player) && player.getCommandSenderWorld().getGameTime() >= until;
    }

    public static boolean isHiddenFrom(LivingEntity viewer, Player player) {
        if (!isHidden(player)) return false;
        // Hidden means visually concealed by the bush from normal enemy AI.
        // Sound/events can still break stealth explicitly.
        return viewer.distanceToSqr(player) <= 96 * 96;
    }

    public static void breakStealth(Player player, int ticks) {
        player.getPersistentData().putLong(
            STEALTH_BROKEN_UNTIL, player.getCommandSenderWorld().getGameTime() + ticks);
    }
}
