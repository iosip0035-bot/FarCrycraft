package com.farcrycraft.block;

import com.farcrycraft.item.WeaponItem;
import com.farcrycraft.item.WeaponSpecs;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import java.util.*;

public class WeaponBenchBlock extends Block {
    private static final WeaponSpecs.Attachment[] CYCLE = WeaponSpecs.Attachment.values();
    public WeaponBenchBlock(Properties p){super(p);}
    @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){
        ItemStack s=player.getItemInHand(hand);
        if(!(s.getItem() instanceof WeaponItem w)){
            if(!level.isClientSide) player.displayClientMessage(Component.literal("Equip a weapon to modify it.").withStyle(ChatFormatting.YELLOW),true);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        WeaponItem.init(s,w.spec());
        var tag=s.getOrCreateTag(); Set<String> set=new LinkedHashSet<>(Arrays.asList(tag.getString("Attachments").split(",")));
        if(set.size()==1 && set.iterator().next().isEmpty()) set.clear();
        int idx=-1; if(!set.isEmpty()) idx=List.of(CYCLE).indexOf(WeaponSpecs.Attachment.valueOf(set.iterator().next()));
        WeaponSpecs.Attachment next=CYCLE[(idx+1)%CYCLE.length]; set.clear(); set.add(next.name()); tag.putString("Attachments",String.join(",",set));
        if(!level.isClientSide) player.displayClientMessage(Component.literal("Attachment: "+next.name().replace('_',' ')).withStyle(ChatFormatting.GREEN),true);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
