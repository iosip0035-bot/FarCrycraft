package com.farcrycraft.block;

import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.Material;

public class StealthBushBlock extends BushBlock {
    public StealthBushBlock() {
        super(BlockBehaviour.Properties.of(Material.LEAVES)
            .noCollission()
            .instabreak()
            .sound(SoundType.GRASS)
            .noOcclusion());
    }
}
