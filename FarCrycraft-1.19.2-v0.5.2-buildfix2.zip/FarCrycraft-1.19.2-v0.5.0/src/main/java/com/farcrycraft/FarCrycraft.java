package com.farcrycraft;

import com.farcrycraft.network.Network;
import com.farcrycraft.registry.ModBlocks;
import com.farcrycraft.registry.ModEntities;
import com.farcrycraft.registry.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FarCrycraft.MODID)
public final class FarCrycraft {
    public static final String MODID = "farcrycraft";
    public FarCrycraft() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        MinecraftForge.EVENT_BUS.register(new com.farcrycraft.common.ServerEvents());
        MinecraftForge.EVENT_BUS.register(new com.farcrycraft.common.OutpostSystem());
        MinecraftForge.EVENT_BUS.register(new com.farcrycraft.common.StealthBushSystem());
        Network.init();
    }
}
