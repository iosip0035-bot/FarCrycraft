package com.farcrycraft.network;
import com.farcrycraft.common.WeaponSystem;
import com.farcrycraft.item.WeaponItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;
public record FirePacket() {
    public static void encode(FirePacket p, FriendlyByteBuf b) {}
    public static FirePacket decode(FriendlyByteBuf b){ return new FirePacket(); }
    public static void handle(FirePacket p, Supplier<NetworkEvent.Context> c){
        c.get().enqueueWork(() -> {
            ServerPlayer sp=c.get().getSender();
            if(sp!=null && sp.getMainHandItem().getItem() instanceof WeaponItem w)
                WeaponSystem.fire(sp,sp.getMainHandItem(),w.spec());
        });
        c.get().setPacketHandled(true);
    }
}
