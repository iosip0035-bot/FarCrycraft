package com.farcrycraft.network;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;
public record ParachutePacket() {
    public static void encode(ParachutePacket p,FriendlyByteBuf b){}
    public static ParachutePacket decode(FriendlyByteBuf b){return new ParachutePacket();}
    public static void handle(ParachutePacket p,Supplier<NetworkEvent.Context> c){
        c.get().enqueueWork(() -> { ServerPlayer sp=c.get().getSender(); if(sp!=null) sp.getPersistentData().putBoolean("FCParachute",!sp.isOnGround()); }); c.get().setPacketHandled(true);
    }
}
