package com.farcrycraft.network;

import com.farcrycraft.item.WeaponItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public record ReloadPacket() {
    public static void encode(ReloadPacket p, FriendlyByteBuf b) {}
    public static ReloadPacket decode(FriendlyByteBuf b) { return new ReloadPacket(); }
    public static void handle(ReloadPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> {
            ServerPlayer sp = c.get().getSender();
            if (sp == null) return;
            if (!(sp.getMainHandItem().getItem() instanceof WeaponItem w)) return;
            var stack = sp.getMainHandItem();
            WeaponItem.init(stack, w.spec());
            var n = stack.getOrCreateTag();
            int have = n.getInt("Ammo");
            int reserve = n.getInt("Reserve");
            if (reserve <= 0 || have >= w.spec().mag()) return;
            int duration = w.spec().id().equals("lmg") ? 18 : w.spec().id().equals("sniper") ? 16 : 12;
            sp.getPersistentData().putInt("FC_ReloadTicks", duration);
        });
        c.get().setPacketHandled(true);
    }
}
