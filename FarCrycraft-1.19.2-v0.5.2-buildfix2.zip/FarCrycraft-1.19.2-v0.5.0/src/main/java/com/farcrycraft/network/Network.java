package com.farcrycraft.network;

import com.farcrycraft.FarCrycraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Network {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(FarCrycraft.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int id = 0;
    public static void init() {
        CH.registerMessage(id++, FirePacket.class, FirePacket::encode, FirePacket::decode, FirePacket::handle);
        CH.registerMessage(id++, ReloadPacket.class, ReloadPacket::encode, ReloadPacket::decode, ReloadPacket::handle);
        CH.registerMessage(id++, ParachutePacket.class, ParachutePacket::encode, ParachutePacket::decode, ParachutePacket::handle);
        CH.registerMessage(id++, VehicleActionPacket.class, VehicleActionPacket::encode, VehicleActionPacket::decode, VehicleActionPacket::handle);
        CH.registerMessage(id++, TakedownPacket.class, TakedownPacket::encode, TakedownPacket::decode, TakedownPacket::handle);
    }
    private Network() {}
}
