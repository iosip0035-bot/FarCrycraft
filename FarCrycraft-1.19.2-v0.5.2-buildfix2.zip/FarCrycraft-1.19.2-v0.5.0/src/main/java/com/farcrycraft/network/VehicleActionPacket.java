package com.farcrycraft.network;

import com.farcrycraft.entity.FarCryVehicleEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record VehicleActionPacket(float forward, float strafe, float pitch) {
    public static void encode(VehicleActionPacket p, FriendlyByteBuf b) {
        b.writeFloat(p.forward);
        b.writeFloat(p.strafe);
        b.writeFloat(p.pitch);
    }
    public static VehicleActionPacket decode(FriendlyByteBuf b) {
        return new VehicleActionPacket(b.readFloat(), b.readFloat(), b.readFloat());
    }
    public static void handle(VehicleActionPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> {
            ServerPlayer player = c.get().getSender();
            if (player != null && player.getVehicle() instanceof FarCryVehicleEntity vehicle) {
                vehicle.getPersistentData().putFloat("FCForward", clamp(p.forward));
                vehicle.getPersistentData().putFloat("FCSide", clamp(p.strafe));
                vehicle.getPersistentData().putFloat("FCPitch", clamp(p.pitch / 45f));
            }
        });
        c.get().setPacketHandled(true);
    }
    private static float clamp(float v) { return Math.max(-1f, Math.min(1f, v)); }
}
