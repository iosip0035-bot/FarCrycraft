package com.farcrycraft.network;

import com.farcrycraft.entity.MercenaryEntity;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public record TakedownPacket() {
    public static void encode(TakedownPacket p, FriendlyByteBuf b) {}
    public static TakedownPacket decode(FriendlyByteBuf b) { return new TakedownPacket(); }
    public static void handle(TakedownPacket p, Supplier<NetworkEvent.Context> c) {
        c.get().enqueueWork(() -> {
            ServerPlayer player = c.get().getSender();
            if (player == null) return;
            MercenaryEntity target = null;
            double best = 3.1;
            var look = player.getLookAngle().normalize();
            for (MercenaryEntity mob : player.getCommandSenderWorld().getEntitiesOfClass(
                    MercenaryEntity.class, player.getBoundingBox().inflate(3.5))) {
                if (mob.isDownedOrCorpse()) continue;
                double distance = player.distanceTo(mob);
                if (distance > 3.0) continue;
                var toMob = mob.getEyePosition().subtract(player.getEyePosition()).normalize();
                if (look.dot(toMob) < 0.45) continue;
                if (!player.hasLineOfSight(mob)) continue;
                if (distance < best) { best = distance; target = mob; }
            }
            if (target != null) {
                target.startMacheteTakedown();
                player.getPersistentData().putInt("FCMacheteAnim", 18);
            }
        });
        c.get().setPacketHandled(true);
    }
}
