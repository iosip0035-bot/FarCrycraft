package com.farcrycraft.client;

import com.farcrycraft.item.NightVisionGogglesItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.farcrycraft.FarCrycraft;

/** Renders the original tactical NV/thermal goggles on the player's head. */
@Mod.EventBusSubscriber(modid = FarCrycraft.MODID, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class NightVisionGogglesLayer {
    private static NightVisionGogglesModel MODEL;

    private NightVisionGogglesLayer() {}

    @SubscribeEvent
    public static void renderPlayer(RenderPlayerEvent.Post event) {
        AbstractClientPlayer player = event.getEntity();
        ItemStack helmet = player.getItemBySlot(EquipmentSlot.HEAD);
        if (!(helmet.getItem() instanceof NightVisionGogglesItem)) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        if (MODEL == null) {
            MODEL = new NightVisionGogglesModel(
                mc.getEntityModels().bakeLayer(NightVisionGogglesModel.LAYER));
        }

        PlayerRenderer renderer = event.getRenderer();
        PlayerModel<AbstractClientPlayer> parent = renderer.getModel();

        PoseStack pose = event.getPoseStack();
        pose.pushPose();

        // Move from player root to the actual animated head bone.
        parent.head.translateAndRotate(pose);
        pose.scale(1.08F, 1.08F, 1.08F);
        pose.translate(0.0F, -0.02F, 0.0F);

        MODEL.animate(
            NightVisionClient.getGoggleDeployProgress(),
            NightVisionClient.getThermalTransitionProgress(),
            NightVisionClient.getModeSwitchPulse());

        VertexConsumer consumer = event.getMultiBufferSource()
            .getBuffer(RenderType.entityCutoutNoCull(NightVisionGogglesModel.TEXTURE));

        MODEL.renderToBuffer(pose, consumer, event.getPackedLight(), OverlayTexture.NO_OVERLAY,
            1.0F, 1.0F, 1.0F, 1.0F);
        pose.popPose();
    }
}
