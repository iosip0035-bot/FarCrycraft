package com.farcrycraft.client;

import net.minecraft.client.model.Model;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import com.farcrycraft.FarCrycraft;

public class NightVisionGogglesModel extends Model {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
        new ResourceLocation(FarCrycraft.MODID, "night_vision_goggles"), "main");
    public static final ResourceLocation TEXTURE = new ResourceLocation(
        FarCrycraft.MODID, "textures/models/night_vision_goggles.png");

    private final ModelPart root;
    private final ModelPart frame;
    private final ModelPart leftLens;
    private final ModelPart rightLens;
    private final ModelPart leftFilter;
    private final ModelPart rightFilter;
    private final ModelPart strap;

    public NightVisionGogglesModel(ModelPart root) {
        super(RenderType::entityCutoutNoCull);
        this.root = root;
        this.frame = root.getChild("frame");
        this.leftLens = root.getChild("left_lens");
        this.rightLens = root.getChild("right_lens");
        this.leftFilter = root.getChild("left_filter");
        this.rightFilter = root.getChild("right_filter");
        this.strap = root.getChild("strap");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("frame",
            CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.8F, -3.5F, -4.9F, 9.6F, 1.0F, 1.4F)
                .texOffs(0, 4).addBox(-5.0F, -3.0F, -4.65F, 1.0F, 4.2F, 1.1F)
                .texOffs(0, 10).addBox(4.0F, -3.0F, -4.65F, 1.0F, 4.2F, 1.1F)
                .texOffs(14, 0).addBox(-0.7F, -3.7F, -5.05F, 1.4F, 0.9F, 1.5F)
                .texOffs(20, 0).addBox(-5.3F, -2.4F, -1.2F, 1.2F, 1.1F, 3.8F)
                .texOffs(20, 5).addBox(4.1F, -2.4F, -1.2F, 1.2F, 1.1F, 3.8F),
            PartPose.ZERO);

        root.addOrReplaceChild("left_lens",
            CubeListBuilder.create()
                .texOffs(32, 0).addBox(-4.0F, -2.8F, -5.25F, 3.1F, 3.2F, 0.75F, new CubeDeformation(0.08F)),
            PartPose.ZERO);

        root.addOrReplaceChild("right_lens",
            CubeListBuilder.create()
                .texOffs(32, 5).addBox(0.9F, -2.8F, -5.25F, 3.1F, 3.2F, 0.75F, new CubeDeformation(0.08F)),
            PartPose.ZERO);

        root.addOrReplaceChild("left_filter",
            CubeListBuilder.create()
                .texOffs(32, 10).addBox(-3.65F, -2.45F, -5.58F, 2.4F, 2.5F, 0.35F, new CubeDeformation(0.03F)),
            PartPose.ZERO);

        root.addOrReplaceChild("right_filter",
            CubeListBuilder.create()
                .texOffs(42, 10).addBox(1.25F, -2.45F, -5.58F, 2.4F, 2.5F, 0.35F, new CubeDeformation(0.03F)),
            PartPose.ZERO);

        root.addOrReplaceChild("strap",
            CubeListBuilder.create()
                .texOffs(0, 17).addBox(-5.7F, -3.0F, -0.7F, 11.4F, 0.9F, 0.9F),
            PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }

    /**
     * deploy = 0..1 physical flip-down of the goggles.
     * thermal = 0..1 filter movement from night vision to thermal.
     * pulse = short activation/mode-switch emphasis.
     */
    public void animate(float deploy, float thermal, float pulse) {
        float d = smooth(deploy);
        float t = smooth(thermal);
        float p = (float) Math.sin(pulse * Math.PI);

        // Lenses lift away from the face when electronics are off and settle into
        // a low-profile tactical position when active.
        leftLens.xRot = -0.68F * (1.0F - d);
        rightLens.xRot = -0.68F * (1.0F - d);
        leftLens.yRot = -0.06F * p;
        rightLens.yRot = 0.06F * p;

        // Thermal filters physically slide/tilt over the lenses. The tiny
        // oscillation gives the mode switch a mechanical "click" feel.
        leftFilter.y = -2.45F + 0.35F * (1.0F - t);
        rightFilter.y = -2.45F + 0.35F * (1.0F - t);
        leftFilter.xRot = 0.30F * (1.0F - t) + 0.08F * p;
        rightFilter.xRot = 0.30F * (1.0F - t) - 0.08F * p;
        leftFilter.zRot = 0.16F * p;
        rightFilter.zRot = -0.16F * p;

        // Frame gives a subtle mechanical lift when toggled.
        frame.xRot = 0.035F * p;
        strap.z = -0.1F * (1.0F - d);
    }

    private static float smooth(float x) {
        x = Math.max(0.0F, Math.min(1.0F, x));
        return x * x * (3.0F - 2.0F * x);
    }


    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer consumer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        root.render(poseStack, consumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
