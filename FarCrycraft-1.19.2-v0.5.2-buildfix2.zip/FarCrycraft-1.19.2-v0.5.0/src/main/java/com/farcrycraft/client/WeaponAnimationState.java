package com.farcrycraft.client;

import com.farcrycraft.item.WeaponItem;
import net.minecraft.client.Minecraft;

public final class WeaponAnimationState {
    private static int equipTicks = 0;
    private static int holsterTicks = 0;
    private static int recoilTicks = 0;
    private static int reloadTicks = 0;
    private static int takedownTicks = 0;
    private static String lastWeapon = "";
    private static boolean lastHeldWeapon = false;
    private static boolean wheelOpen = false;

    private WeaponAnimationState() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        var held = mc.player.getMainHandItem();
        String current = held.getItem() instanceof WeaponItem w ? w.spec().id() : "";
        boolean holdingWeapon = !current.isEmpty();

        if (holdingWeapon != lastHeldWeapon) {
            if (holdingWeapon) {
                startDraw();
            } else if (lastHeldWeapon) {
                startHolster();
            }
            lastHeldWeapon = holdingWeapon;
        }

        if (holdingWeapon && !current.equals(lastWeapon)) {
            // Switching between two guns: briefly lower the previous weapon and
            // bring the new one up rather than snapping instantly.
            startHolster();
            equipTicks = Math.max(equipTicks, 10);
            lastWeapon = current;
        }

        if (!holdingWeapon) lastWeapon = "";
        if (equipTicks > 0) equipTicks--;
        if (holsterTicks > 0) holsterTicks--;
        if (recoilTicks > 0) recoilTicks--;
        if (reloadTicks > 0) reloadTicks--;
        if (takedownTicks > 0) takedownTicks--;
    }

    public static void startDraw() {
        equipTicks = 10;
        holsterTicks = 0;
    }

    public static void startHolster() {
        holsterTicks = 8;
        equipTicks = 0;
    }

    public static void setWheelOpen(boolean open) {
        wheelOpen = open;
    }

    public static boolean isWheelOpen() {
        return wheelOpen;
    }

    public static void fire() { recoilTicks = 4; }
    public static void reload() { reloadTicks = 12; }
    public static void takedown() { takedownTicks = 20; }

    public static float equipProgress(float partial) {
        return Math.max(0f, Math.min(1f, (equipTicks - partial) / 10f));
    }

    public static float holsterProgress(float partial) {
        return Math.max(0f, Math.min(1f, (holsterTicks - partial) / 8f));
    }

    public static float recoilProgress(float partial) {
        return Math.max(0f, (recoilTicks - partial) / 4f);
    }

    public static float reloadProgress(float partial) {
        return Math.max(0f, (reloadTicks - partial) / 12f);
    }

    public static boolean isReloading() { return reloadTicks > 0; }
    public static float takedownProgress(float partial) { return Math.max(0f, (takedownTicks - partial) / 20f); }
    public static boolean isTakedown() { return takedownTicks > 0; }
}
