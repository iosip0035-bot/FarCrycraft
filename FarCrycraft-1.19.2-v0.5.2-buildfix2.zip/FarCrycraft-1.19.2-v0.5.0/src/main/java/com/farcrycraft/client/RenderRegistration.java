package com.farcrycraft.client;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.client.model.MercenaryModel;
import com.farcrycraft.client.model.MercenaryRenderer;
import com.farcrycraft.client.model.VehicleModel;
import com.farcrycraft.client.model.VehicleRenderer;
import com.farcrycraft.registry.ModEntities;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=FarCrycraft.MODID,bus=Mod.EventBusSubscriber.Bus.MOD,value=net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class RenderRegistration {
    public static final ModelLayerLocation MERCENARY_LAYER=new ModelLayerLocation(new ResourceLocation(FarCrycraft.MODID,"mercenary"),"main");
    public static final ModelLayerLocation VEHICLE_LAYER=new ModelLayerLocation(new ResourceLocation(FarCrycraft.MODID,"vehicle"),"main");
    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e){e.registerLayerDefinition(MERCENARY_LAYER,MercenaryModel::createLayer);
        e.registerLayerDefinition(VEHICLE_LAYER,VehicleModel::createLayer);}
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e){
        e.registerEntityRenderer(ModEntities.MERCENARY.get(),ctx->new MercenaryRenderer(ctx,MERCENARY_LAYER));
        e.registerEntityRenderer(ModEntities.HEAVY.get(),ctx->new MercenaryRenderer(ctx,MERCENARY_LAYER));
        e.registerEntityRenderer(ModEntities.SNIPER.get(),ctx->new MercenaryRenderer(ctx,MERCENARY_LAYER));
        e.registerEntityRenderer(ModEntities.MG.get(),ctx->new MercenaryRenderer(ctx,MERCENARY_LAYER));
        e.registerEntityRenderer(ModEntities.VEHICLE.get(),ctx->new VehicleRenderer(ctx,new VehicleModel(ctx.bakeLayer(VEHICLE_LAYER))));
    }
    private RenderRegistration(){}
}
