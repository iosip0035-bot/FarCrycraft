package com.farcrycraft.client;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.item.WeaponItem;
import com.farcrycraft.network.FirePacket;
import com.farcrycraft.network.Network;
import com.farcrycraft.network.ParachutePacket;
import com.farcrycraft.network.ReloadPacket;
import com.farcrycraft.network.TakedownPacket;
import com.farcrycraft.network.VehicleActionPacket;
import com.farcrycraft.entity.FarCryVehicleEntity;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=FarCrycraft.MODID, value=net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ClientInput {
    public static final KeyMapping RELOAD = new KeyMapping("key.farcrycraft.reload", GLFW.GLFW_KEY_R, "key.categories.farcrycraft");
    public static final KeyMapping PARACHUTE = new KeyMapping("key.farcrycraft.parachute", GLFW.GLFW_KEY_G, "key.categories.farcrycraft");
    public static final KeyMapping TAKEDOWN = new KeyMapping("key.farcrycraft.takedown", GLFW.GLFW_KEY_V, "key.categories.farcrycraft");
    public static final KeyMapping WEAPON_WHEEL = new KeyMapping("key.farcrycraft.weapon_wheel", GLFW.GLFW_KEY_TAB, "key.categories.farcrycraft");

    @SubscribeEvent
    public static void interaction(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && !(mc.screen instanceof WeaponWheelScreen)
                && mc.player.getMainHandItem().getItem() instanceof WeaponItem && e.isAttack()) {
            e.setCanceled(true);
            WeaponAnimationState.fire();
            Network.CH.sendToServer(new FirePacket());
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        WeaponAnimationState.tick();
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        if (mc.player.getVehicle() instanceof FarCryVehicleEntity) {
            float forward = 0f;
            if (mc.options.keyUp.isDown()) forward += 1f;
            if (mc.options.keyDown.isDown()) forward -= 1f;
            float strafe = 0f;
            if (mc.options.keyLeft.isDown()) strafe += 1f;
            if (mc.options.keyRight.isDown()) strafe -= 1f;
            Network.CH.sendToServer(new VehicleActionPacket(forward, strafe, mc.player.getXRot()));
        }

        if (RELOAD.consumeClick()) {
            WeaponAnimationState.reload();
            Network.CH.sendToServer(new ReloadPacket());
        }
        if (PARACHUTE.consumeClick() && !mc.player.isOnGround()) {
            Network.CH.sendToServer(new ParachutePacket());
        }
        if (TAKEDOWN.consumeClick()) {
            WeaponAnimationState.takedown();
            Network.CH.sendToServer(new TakedownPacket());
        }

        boolean down = WEAPON_WHEEL.isDown();
        if (down && !(mc.screen instanceof WeaponWheelScreen)) {
            WeaponAnimationState.setWheelOpen(true);
            mc.setScreen(new WeaponWheelScreen());
        } else if (!down && mc.screen instanceof WeaponWheelScreen wheel) {
            wheel.finishSelection();
            WeaponAnimationState.setWheelOpen(false);
            WeaponAnimationState.startDraw();
            mc.setScreen(null);
        }
    }

    @Mod.EventBusSubscriber(modid=FarCrycraft.MODID, bus=Mod.EventBusSubscriber.Bus.MOD, value=net.minecraftforge.api.distmarker.Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void register(RegisterKeyMappingsEvent e) {
            e.register(RELOAD);
            e.register(PARACHUTE);
            e.register(TAKEDOWN);
            e.register(WEAPON_WHEEL);
        }
    }

    private ClientInput() {}
}
