package com.farcrycraft.client;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.item.NightVisionGogglesItem;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(
    modid = FarCrycraft.MODID,
    bus = Mod.EventBusSubscriber.Bus.MOD,
    value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class NightVisionClient {
    public static final KeyMapping NVG_KEY = new KeyMapping(
        "key.farcrycraft.night_vision", GLFW.GLFW_KEY_N, "key.categories.farcrycraft");

    private static boolean active;
    private static boolean thermal;
    private static boolean previousDown;
    private static boolean previousThermal;
    private static boolean appliedNightVision;
    private static float goggleDeployProgress;
    private static float thermalTransitionProgress;
    private static float modeSwitchPulse;
    private static final Map<UUID, Boolean> previousGlow = new HashMap<>();

    private NightVisionClient() {}

    public static boolean isActive() { return active; }
    public static boolean isThermal() { return thermal; }
    public static float getGoggleDeployProgress() { return goggleDeployProgress; }
    public static float getThermalTransitionProgress() { return thermalTransitionProgress; }
    public static float getModeSwitchPulse() { return modeSwitchPulse; }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(NVG_KEY);
    }

    @Mod.EventBusSubscriber(
        modid = FarCrycraft.MODID,
        bus = Mod.EventBusSubscriber.Bus.FORGE,
        value = net.minecraftforge.api.distmarker.Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        @SubscribeEvent
        public static void clientTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer player = mc.player;
            if (player == null) return;

            boolean wearing = player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof NightVisionGogglesItem;
            boolean down = NVG_KEY.isDown();

            if (!wearing) {
                active = false;
                thermal = false;
                previousDown = down;
                previousThermal = false;
                clearNightVision(player);
                clearThermal(mc);
                updateAnimationState(false, false);
                return;
            }

            // Tap N: ON -> OFF. First press turns night vision on.
            if (down && !previousDown) {
                active = !active;
                if (!active) thermal = false;
            }

            // Hold N while active: thermal mode. Release N: return to night vision.
            thermal = active && down;

            if (thermal != previousThermal) {
                modeSwitchPulse = 1.0F;
                previousThermal = thermal;
            }

            previousDown = down;

            if (active) {
                if (!hasNightVision(player)) {
                    player.addEffect(new MobEffectInstance(
                        MobEffects.NIGHT_VISION, 12, 0, true, false, false));
                    appliedNightVision = true;
                }
                if (thermal) updateThermal(mc);
                else clearThermal(mc);
            } else {
                clearNightVision(player);
                clearThermal(mc);
            }

            updateAnimationState(active, thermal);
        }

        private static void updateAnimationState(boolean targetActive, boolean targetThermal) {
            float speed = 0.16F;
            goggleDeployProgress += (targetActive ? 1F : 0F) - goggleDeployProgress > 0
                ? speed : -speed;
            goggleDeployProgress = clamp01(goggleDeployProgress);

            float thermalTarget = targetThermal ? 1F : 0F;
            thermalTransitionProgress += (thermalTarget - thermalTransitionProgress) * 0.24F;
            thermalTransitionProgress = clamp01(thermalTransitionProgress);

            modeSwitchPulse = Math.max(0F, modeSwitchPulse - 0.13F);
        }

        private static float clamp01(float x) { return Math.max(0F, Math.min(1F, x)); }

        private static boolean hasNightVision(LocalPlayer p) {
            MobEffectInstance e = p.getEffect(MobEffects.NIGHT_VISION);
            return e != null && e.getDuration() > 2;
        }

        private static void clearNightVision(LocalPlayer p) {
            if (appliedNightVision) {
                p.removeEffect(MobEffects.NIGHT_VISION);
                appliedNightVision = false;
            }
        }

        private static void updateThermal(Minecraft mc) {
            if (mc.level == null || mc.player == null) return;
            for (LivingEntity entity : mc.level.getEntitiesOfClass(
                LivingEntity.class,
                mc.player.getBoundingBox().inflate(42.0),
                e -> e != mc.player && e.isAlive())) {
                previousGlow.putIfAbsent(entity.getUUID(), entity.hasGlowingTag());
                entity.setGlowingTag(true);
            }
        }

        private static void clearThermal(Minecraft mc) {
            if (mc.level == null) {
                previousGlow.clear();
                return;
            }
            for (Map.Entry<UUID, Boolean> entry : previousGlow.entrySet()) {
                for (LivingEntity entity : mc.level.getEntitiesOfClass(
                    LivingEntity.class,
                    mc.player.getBoundingBox().inflate(48),
                    e -> e.getUUID().equals(entry.getKey()))) {
                    entity.setGlowingTag(entry.getValue());
                    break;
                }
            }
            previousGlow.clear();
        }

        @SubscribeEvent
        public static void overlay(RenderGuiOverlayEvent.Post e) {
            if (!e.getOverlay().id().equals(net.minecraftforge.client.gui.overlay.VanillaGuiOverlay.HOTBAR.id())) return;
            if (!active) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return;
            int h = e.getWindow().getGuiScaledHeight();
            int c = thermal ? 0x66FFCC : 0x66FF66;
            mc.font.draw(e.getPoseStack(), thermal ? "THERMAL" : "NIGHT VISION", 8, 8, c);
            mc.font.draw(e.getPoseStack(), "N: toggle | hold N: thermal", 8, h - 32, 0xDDDDDD);
        }
    }
}
