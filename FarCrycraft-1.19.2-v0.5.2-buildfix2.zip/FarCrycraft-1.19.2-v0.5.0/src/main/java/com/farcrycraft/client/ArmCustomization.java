package com.farcrycraft.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Client-side persistent customization for the first-person arms. */
public final class ArmCustomization {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public float skinR = 0.76f;
    public float skinG = 0.57f;
    public float skinB = 0.44f;

    public float sleeveR = 0.24f;
    public float sleeveG = 0.34f;
    public float sleeveB = 0.18f;

    public boolean gloves = false;
    public boolean wristBand = true;
    public int sleeveStyle = 0; // 0 = rolled, 1 = short, 2 = long

    public transient Path file;

    private static ArmCustomization INSTANCE;

    public static ArmCustomization get() {
        if (INSTANCE == null) {
            INSTANCE = new ArmCustomization();
            INSTANCE.file = defaultPath();
            INSTANCE.load();
        }
        return INSTANCE;
    }

    private static Path defaultPath() {
        return net.minecraft.client.Minecraft.getInstance().gameDirectory.toPath()
            .resolve("config").resolve("farcrycraft_arms.json");
    }

    public void save() {
        try {
            Files.createDirectories(file.getParent());
            ArmCustomization copy = new ArmCustomization();
            copy.skinR = skinR; copy.skinG = skinG; copy.skinB = skinB;
            copy.sleeveR = sleeveR; copy.sleeveG = sleeveG; copy.sleeveB = sleeveB;
            copy.gloves = gloves; copy.wristBand = wristBand; copy.sleeveStyle = sleeveStyle;
            try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                GSON.toJson(copy, writer);
            }
        } catch (IOException ignored) {
            // Client cosmetic settings should never interrupt the game.
        }
    }

    private void load() {
        if (!Files.isRegularFile(file)) return;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            ArmCustomization loaded = GSON.fromJson(reader, ArmCustomization.class);
            if (loaded == null) return;
            skinR = clamp(loaded.skinR); skinG = clamp(loaded.skinG); skinB = clamp(loaded.skinB);
            sleeveR = clamp(loaded.sleeveR); sleeveG = clamp(loaded.sleeveG); sleeveB = clamp(loaded.sleeveB);
            gloves = loaded.gloves;
            wristBand = loaded.wristBand;
            sleeveStyle = Math.max(0, Math.min(2, loaded.sleeveStyle));
        } catch (Exception ignored) {
            // Keep defaults if the file is corrupt or from an older version.
        }
    }

    public void setSkin(float r, float g, float b) {
        skinR = clamp(r); skinG = clamp(g); skinB = clamp(b);
    }

    public void setSleeve(float r, float g, float b) {
        sleeveR = clamp(r); sleeveG = clamp(g); sleeveB = clamp(b);
    }

    public void reset() {
        skinR = 0.76f; skinG = 0.57f; skinB = 0.44f;
        sleeveR = 0.24f; sleeveG = 0.34f; sleeveB = 0.18f;
        gloves = false; wristBand = true; sleeveStyle = 0;
        save();
    }

    private static float clamp(float v) {
        return Math.max(0f, Math.min(1f, v));
    }
}
