package com.farcrycraft.client;

import com.farcrycraft.FarCrycraft;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Vector3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=FarCrycraft.MODID, bus=Mod.EventBusSubscriber.Bus.MOD,
    value=net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ArmCustomizationClient {
    public static final net.minecraft.client.model.geom.ModelLayerLocation ARMS_LAYER =
        new net.minecraft.client.model.geom.ModelLayerLocation(
            new ResourceLocation(FarCrycraft.MODID, "first_person_arms"), "main");

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(ARMS_LAYER, FirstPersonArmsModel::createLayer);
    }

    @Mod.EventBusSubscriber(modid=FarCrycraft.MODID, bus=Mod.EventBusSubscriber.Bus.FORGE,
        value=net.minecraftforge.api.distmarker.Dist.CLIENT)
    public static class Screens {
        @SubscribeEvent
        public static void pause(ScreenEvent.Init.Post e) {
            if (!(e.getScreen() instanceof PauseScreen)) return;
            int x = e.getScreen().width - 34;
            int y = e.getScreen().height - 34;
            e.addListener(new ArmsPauseButton(x, y, 24, 24,
                b -> Minecraft.getInstance().setScreen(new ArmCustomizationScreen(e.getScreen()))));
        }
    }

    private ArmCustomizationClient() {}
}
