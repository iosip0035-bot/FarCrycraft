package com.farcrycraft.client;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Vector3f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=FarCrycraft.MODID, value=net.minecraftforge.api.distmarker.Dist.CLIENT)
public class FirstPersonArms {
    private static FirstPersonArmsModel model;
    private static final ResourceLocation ARMS_TEXTURE =
        new ResourceLocation(FarCrycraft.MODID, "textures/models/fps_arms.png");

    private static FirstPersonArmsModel model() {
        if (model == null) {
            model = new FirstPersonArmsModel(
                Minecraft.getInstance().getEntityModels().bakeLayer(ArmCustomizationClient.ARMS_LAYER));
        }
        return model;
    }

    @SubscribeEvent
    public static void render(RenderHandEvent e) {
        // We fully own first-person right hand rendering so the customized arms
        // appear behind/around the weapon instead of using the vanilla hand.
        if (e.getHand() != InteractionHand.MAIN_HAND) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) return;
        e.setCanceled(true);

        PoseStack pose = e.getPoseStack();
        ArmCustomization c = ArmCustomization.get();
        FirstPersonArmsModel arms = model();

        pose.pushPose();
        pose.translate(0.0f, -0.34f, 0.38f);
        pose.scale(0.085f, 0.085f, 0.085f);
        pose.mulPose(Vector3f.XP.rotationDegrees(16f));

        boolean aiming = mc.options.keyUse.isDown();
        boolean reloading = WeaponAnimationState.isReloading();
        arms.setup(aiming, reloading, p.tickCount + e.getPartialTick());

        MultiBufferSource buffers = e.getMultiBufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(ARMS_TEXTURE));
        arms.render(pose, vc, e.getPackedLight(), OverlayTexture.NO_OVERLAY, c, 1f);
        pose.popPose();

        // Takedown: render arms + a temporary machete visual.
        if (WeaponAnimationState.isTakedown()) {
            pose.pushPose();
            float progress = 1f - WeaponAnimationState.takedownProgress(e.getPartialTick());
            float swing = (float)Math.sin(progress * Math.PI);
            pose.translate(0.34f, -0.12f + swing * 0.06f, -0.55f + swing * 0.10f);
            pose.mulPose(Vector3f.YP.rotationDegrees(-18f + swing * 42f));
            pose.mulPose(Vector3f.XP.rotationDegrees(-38f + swing * 105f));
            pose.mulPose(Vector3f.ZP.rotationDegrees(-12f + swing * 55f));
            ItemRenderer renderer = mc.getItemRenderer();
            ItemStack machete = new ItemStack(ModItems.MACHETE.get());
            renderer.renderStatic(machete, ItemTransforms.TransformType.FIRST_PERSON_RIGHT_HAND,
                e.getPackedLight(), OverlayTexture.NO_OVERLAY, pose, buffers, 0);
            pose.popPose();
            return;
        }

        ItemStack held = p.getMainHandItem();
        if (held.isEmpty()) return;

        pose.pushPose();
        applyWeaponPose(pose, p, held, e.getPartialTick());
        mc.getItemRenderer().renderStatic(held,
            ItemTransforms.TransformType.FIRST_PERSON_RIGHT_HAND,
            e.getPackedLight(), OverlayTexture.NO_OVERLAY, pose, buffers, 0);
        pose.popPose();
    }

    private static void applyWeaponPose(PoseStack pose, LocalPlayer p, ItemStack held, float partial) {
        float t = p.tickCount + partial;
        pose.translate((float)Math.sin(t*.045f)*.006f, (float)Math.cos(t*.035f)*.004f, 0);

        if (WeaponAnimationState.isWheelOpen()) {
            pose.translate(0,-.20f,.22f);
            pose.mulPose(Vector3f.XP.rotationDegrees(10f));
        }

        float equip = WeaponAnimationState.equipProgress(partial);
        if (equip > 0) {
            float q = 1f - equip;
            float smooth = q*q*(3f-2f*q);
            pose.translate(0,-.30f*(1f-smooth),-.52f*(1f-smooth));
            pose.mulPose(Vector3f.XP.rotationDegrees(-13f*(1f-smooth)));
        }

        float holster = WeaponAnimationState.holsterProgress(partial);
        if (holster > 0) {
            float h = holster*holster;
            pose.translate(.06f*h,-.18f*h,.34f*h);
            pose.mulPose(Vector3f.XP.rotationDegrees(16f*h));
        }

        float recoil = WeaponAnimationState.recoilProgress(partial);
        if (recoil > 0) {
            float kick=recoil*recoil;
            pose.translate(0,-.025f*kick,-.12f*kick);
            pose.mulPose(Vector3f.XP.rotationDegrees(5.5f*kick));
        }

        float reload = WeaponAnimationState.reloadProgress(partial);
        if (reload > 0) {
            float r=(float)Math.sin(reload*Math.PI);
            pose.translate(.075f*r,-.14f*r,-.08f*r);
            pose.mulPose(Vector3f.ZP.rotationDegrees(9f*r));
            pose.mulPose(Vector3f.XP.rotationDegrees(12f*r));
        }
    }
}
