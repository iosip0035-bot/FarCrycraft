package com.farcrycraft.client;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ArmCustomizationScreen extends Screen {
 private final Screen parent; private final ArmCustomization settings;
 public ArmCustomizationScreen(Screen parent){super(Component.translatable("screen.farcrycraft.arms"));this.parent=parent;this.settings=ArmCustomization.get();}
 private Button btn(int x,int y,String label,Button.OnPress press){return new Button(x,y,120,20,Component.literal(label),press);}
 @Override protected void init(){
  int cx=width/2, top=Math.max(30,height/2-95);
  addRenderableWidget(btn(cx-190,top,"Skin 1",b->skin(.93f,.75f,.60f)));
  addRenderableWidget(btn(cx-60,top,"Skin 2",b->skin(.76f,.57f,.44f)));
  addRenderableWidget(btn(cx+70,top,"Skin 3",b->skin(.52f,.36f,.25f)));
  addRenderableWidget(btn(cx-190,top+28,"Skin 4",b->skin(.32f,.20f,.13f)));
  addRenderableWidget(btn(cx-60,top+28,"Olive",b->sleeve(.24f,.34f,.18f)));
  addRenderableWidget(btn(cx+70,top+28,"Black",b->sleeve(.06f,.07f,.08f)));
  addRenderableWidget(btn(cx-190,top+56,"Tan",b->sleeve(.37f,.28f,.18f)));
  addRenderableWidget(btn(cx-60,top+56,"Blue",b->sleeve(.12f,.20f,.42f)));
  addRenderableWidget(btn(cx+70,top+56,"Gloves: "+(settings.gloves?"ON":"OFF"),b->{settings.gloves=!settings.gloves;settings.save();reopen();}));
  addRenderableWidget(btn(cx-190,top+84,"Band: "+(settings.wristBand?"ON":"OFF"),b->{settings.wristBand=!settings.wristBand;settings.save();reopen();}));
  addRenderableWidget(btn(cx-60,top+84,"Sleeves: "+sleeveName(),b->{settings.sleeveStyle=(settings.sleeveStyle+1)%3;settings.save();reopen();}));
  addRenderableWidget(btn(cx+70,top+84,"Reset",b->{settings.reset();settings.save();reopen();}));
  addRenderableWidget(new Button(cx-60,top+116,120,20,Component.translatable("gui.done"),b->onClose()));
 }
 private void reopen(){minecraft.setScreen(new ArmCustomizationScreen(parent));}
 private void skin(float r,float g,float b){settings.skinR=r;settings.skinG=g;settings.skinB=b;settings.save();reopen();}
 private void sleeve(float r,float g,float b){settings.sleeveR=r;settings.sleeveG=g;settings.sleeveB=b;settings.save();reopen();}
 private String sleeveName(){return switch(settings.sleeveStyle){case 1->"SHORT";case 2->"LONG";default->"ROLLED";};}
 @Override public void onClose(){minecraft.setScreen(parent);}
}
