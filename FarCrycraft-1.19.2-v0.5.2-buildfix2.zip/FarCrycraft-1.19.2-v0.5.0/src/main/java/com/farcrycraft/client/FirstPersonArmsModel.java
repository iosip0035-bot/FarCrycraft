package com.farcrycraft.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;

/** Simple first-person arm rig with separately tintable sleeves, skin and gloves. */
public class FirstPersonArmsModel {
    public final ModelPart root;
    public final ModelPart rightUpper;
    public final ModelPart rightForearm;
    public final ModelPart rightHand;
    public final ModelPart rightBand;
    public final ModelPart leftUpper;
    public final ModelPart leftForearm;
    public final ModelPart leftHand;
    public final ModelPart leftBand;

    public FirstPersonArmsModel(ModelPart root) {
        this.root = root;
        this.rightUpper = root.getChild("right_upper");
        this.rightForearm = root.getChild("right_forearm");
        this.rightHand = root.getChild("right_hand");
        this.rightBand = root.getChild("right_band");
        this.leftUpper = root.getChild("left_upper");
        this.leftForearm = root.getChild("left_forearm");
        this.leftHand = root.getChild("left_hand");
        this.leftBand = root.getChild("left_band");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation none = new CubeDeformation(0.0f);

        root.addOrReplaceChild("right_upper",
            CubeListBuilder.create().texOffs(0,0).addBox(-2,-5,-2,4,5,4,none),
            PartPose.offset(-5,5,0));
        root.addOrReplaceChild("right_forearm",
            CubeListBuilder.create().texOffs(0,18).addBox(-2,0,-2,4,7,4,none),
            PartPose.offset(-5,0,0));
        root.addOrReplaceChild("right_hand",
            CubeListBuilder.create().texOffs(16,18).addBox(-2,7,-2,4,3,4,none),
            PartPose.offset(-5,0,0));
        root.addOrReplaceChild("right_band",
            CubeListBuilder.create().texOffs(32,18).addBox(-2,-1,-2.1f,4,1,4.2f,none),
            PartPose.offset(-5,5,0));

        root.addOrReplaceChild("left_upper",
            CubeListBuilder.create().texOffs(0,0).addBox(-2,-5,-2,4,5,4,none),
            PartPose.offset(5,5,0));
        root.addOrReplaceChild("left_forearm",
            CubeListBuilder.create().texOffs(0,18).addBox(-2,0,-2,4,7,4,none),
            PartPose.offset(5,0,0));
        root.addOrReplaceChild("left_hand",
            CubeListBuilder.create().texOffs(16,18).addBox(-2,7,-2,4,3,4,none),
            PartPose.offset(5,0,0));
        root.addOrReplaceChild("left_band",
            CubeListBuilder.create().texOffs(32,18).addBox(-2,-1,-2.1f,4,1,4.2f,none),
            PartPose.offset(5,5,0));

        return LayerDefinition.create(mesh, 64, 64);
    }

    public void setup(boolean aiming, boolean reloading, float movementTime) {
        float walk = (float)Math.sin(movementTime * 0.08f);
        float counter = aiming ? 0.15f : 1f;
        rightUpper.xRot = (float)Math.toRadians(-10) + walk * .025f * counter;
        leftUpper.xRot = (float)Math.toRadians(-12) - walk * .025f * counter;
        rightForearm.xRot = (float)Math.toRadians(-8);
        leftForearm.xRot = (float)Math.toRadians(-10);

        if (aiming) {
            rightUpper.xRot -= .09f;
            leftUpper.xRot -= .09f;
            rightForearm.xRot -= .12f;
            leftForearm.xRot -= .12f;
        }
        if (reloading) {
            rightUpper.zRot = .10f;
            leftUpper.zRot = -.10f;
            rightForearm.zRot = .05f;
            leftForearm.zRot = -.05f;
        } else {
            rightUpper.zRot = leftUpper.zRot = 0f;
            rightForearm.zRot = leftForearm.zRot = 0f;
        }
    }

    public void render(PoseStack pose, VertexConsumer consumer, int light, int overlay,
                       ArmCustomization c, float alpha) {
        boolean gloves = c.gloves;
        boolean band = c.wristBand;

        root.visible = true;
        root.xRot = 0;
        root.yRot = 0;
        root.zRot = 0;

        rightUpper.render(pose, consumer, light, overlay, c.sleeveR, c.sleeveG, c.sleeveB, alpha);
        leftUpper.render(pose, consumer, light, overlay, c.sleeveR, c.sleeveG, c.sleeveB, alpha);

        // Rolled/short/long sleeve is represented by how much sleeve tint is applied.
        float skinMix = switch (c.sleeveStyle) {
            case 1 -> 0.18f; // short
            case 2 -> 0.06f; // long
            default -> 0.12f; // rolled
        };
        float sleeveBlend = 1f - skinMix;
        rightForearm.render(pose, consumer, light, overlay,
            c.skinR * skinMix + c.sleeveR * sleeveBlend,
            c.skinG * skinMix + c.sleeveG * sleeveBlend,
            c.skinB * skinMix + c.sleeveB * sleeveBlend, alpha);
        leftForearm.render(pose, consumer, light, overlay,
            c.skinR * skinMix + c.sleeveR * sleeveBlend,
            c.skinG * skinMix + c.sleeveG * sleeveBlend,
            c.skinB * skinMix + c.sleeveB * sleeveBlend, alpha);

        if (gloves) {
            rightHand.render(pose, consumer, light, overlay, .08f,.08f,.08f,alpha);
            leftHand.render(pose, consumer, light, overlay, .08f,.08f,.08f,alpha);
        } else {
            rightHand.render(pose, consumer, light, overlay, c.skinR,c.skinG,c.skinB,alpha);
            leftHand.render(pose, consumer, light, overlay, c.skinR,c.skinG,c.skinB,alpha);
        }

        if (band) {
            rightBand.render(pose, consumer, light, overlay, .12f,.12f,.12f,alpha);
            leftBand.render(pose, consumer, light, overlay, .12f,.12f,.12f,alpha);
        }
    }
}
