package com.farcrycraft.client;
import com.farcrycraft.FarCrycraft;
import com.farcrycraft.item.WeaponItem;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=FarCrycraft.MODID,bus=Mod.EventBusSubscriber.Bus.FORGE,value=net.minecraftforge.api.distmarker.Dist.CLIENT)
public class Hud {
 @SubscribeEvent public static void hud(RenderGuiOverlayEvent.Post e){if(!e.getOverlay().id().equals(net.minecraftforge.client.gui.overlay.VanillaGuiOverlay.HOTBAR.id()))return;Minecraft mc=Minecraft.getInstance();if(mc.player==null)return;int w=e.getWindow().getGuiScaledWidth(),h=e.getWindow().getGuiScaledHeight();mc.font.draw(e.getPoseStack(),"+",w/2f-3,h/2f-6,0xFFFFFF);mc.font.draw(e.getPoseStack(),"HP "+Math.round(mc.player.getHealth()),8,h-18,0xFFFFFF);
if(com.farcrycraft.common.StealthSystem.isHidden(mc.player)){
    mc.font.draw(e.getPoseStack(),"STEALTH",w/2f-25,h/2f+20,0x55FF55);
    mc.font.draw(e.getPoseStack(),"HIDDEN IN BUSH",w/2f-42,h/2f+34,0x88FF88);
}if(mc.player.getMainHandItem().getItem() instanceof WeaponItem wi){WeaponItem.init(mc.player.getMainHandItem(),wi.spec());var n=mc.player.getMainHandItem().getOrCreateTag();mc.font.draw(e.getPoseStack(),wi.spec().id().toUpperCase(),w-150,h-38,0xFFFFFF);mc.font.draw(e.getPoseStack(),n.getInt("Ammo")+" / "+n.getInt("Reserve"),w-150,h-22,0xFFFFFF);}}
}
