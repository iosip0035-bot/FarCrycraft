package com.farcrycraft.client.model;

import com.farcrycraft.entity.FarCryVehicleEntity;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class VehicleRenderer extends EntityRenderer<FarCryVehicleEntity> {
    private final VehicleModel model;
    private static final ResourceLocation TEXTURE = new ResourceLocation("minecraft", "textures/block/iron_block.png");

    public VehicleRenderer(EntityRendererProvider.Context context, VehicleModel model) {
        super(context);
        this.model = model;
        this.shadowRadius = 1.2f;
    }

    @Override
    public void render(FarCryVehicleEntity entity, float yaw, float partialTick,
                       com.mojang.blaze3d.vertex.PoseStack pose,
                       net.minecraft.client.renderer.MultiBufferSource buffer, int light) {
        pose.pushPose();
        pose.translate(0, 0.55, 0);
        pose.mulPose(com.mojang.math.Vector3f.YP.rotationDegrees(180f - yaw));
        model.setupAnim(entity, 0, 0, entity.tickCount + partialTick, 0, 0);
        var vc = buffer.getBuffer(net.minecraft.client.renderer.RenderType.entitySolid(TEXTURE));
        model.renderToBuffer(pose, vc, light, OverlayTexture.NO_OVERLAY, 0.75f, 0.78f, 0.72f, 1f);
        pose.popPose();
        super.render(entity, yaw, partialTick, pose, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(FarCryVehicleEntity entity) {
        return TEXTURE;
    }
}
