package com.farcrycraft.client.model;

import com.farcrycraft.entity.MercenaryEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.util.Mth;

public class MercenaryModel extends HumanoidModel<MercenaryEntity> {
    public final ModelPart chestPlate;
    public MercenaryModel(ModelPart root){
        super(root);
        this.chestPlate = root.getChild("chest_plate");
    }
    public static LayerDefinition createLayer(){
        MeshDefinition mesh=HumanoidModel.createMesh(CubeDeformation.NONE,0);
        PartDefinition root=mesh.getRoot();
        root.addOrReplaceChild("chest_plate",CubeListBuilder.create().texOffs(0,32).addBox(-4.5f,1f,-2.7f,9,9,1),PartPose.ZERO);
        return LayerDefinition.create(mesh,64,64);
    }
    @Override public void setupAnim(MercenaryEntity e,float limbSwing,float limbSwingAmount,float age,float yaw,float pitch){
        super.setupAnim(e,limbSwing,limbSwingAmount,age,yaw,pitch);
        float breath=Mth.sin(age*.12f)*.02f;
        chestPlate.xRot=breath;
        if(e.role().equals("sniper")){ rightArm.xRot=-1.25f; leftArm.xRot=-1.05f; }
        else if(e.role().equals("machine_gunner")){ rightArm.xRot=-.9f; leftArm.xRot=-.9f; }
        chestPlate.yRot=Mth.sin(age*.08f)*.02f;
        if(e.isReloading()){
            rightArm.xRot=-1.45f;
            leftArm.xRot=-1.05f;
            body.yRot=Mth.sin(age*.35f)*.02f;
        }
        if(e.isAlert()){
            head.xRot -= .10f;
            body.yRot += Mth.sin(age*.28f)*.015f;
        }
        if(e.isTakedownActive()){
            rightArm.xRot=1.35f;
            leftArm.xRot=1.05f;
            head.xRot=.35f;
            body.xRot=-.35f;
        }
        if(e.isDownedOrCorpse() && !e.isTakedownActive()){
            body.xRot=1.15f;
            rightArm.xRot=1.45f;
            leftArm.xRot=1.35f;
            rightLeg.xRot=.75f;
            leftLeg.xRot=.55f;
        }
    }
}
