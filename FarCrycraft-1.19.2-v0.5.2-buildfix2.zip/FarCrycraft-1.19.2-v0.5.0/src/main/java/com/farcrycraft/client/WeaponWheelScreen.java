package com.farcrycraft.client;

import com.farcrycraft.item.WeaponItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.Screen;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public final class WeaponWheelScreen extends Screen {
    private int selected = 0;

    public WeaponWheelScreen() { super(Component.literal("Weapon Wheel")); }

    private int selectedSlot(double mouseX, double mouseY) {
        double cx = width / 2.0, cy = height / 2.0;
        double angle = Math.atan2(mouseY - cy, mouseX - cx) + Math.PI / 2.0;
        if (angle < 0) angle += Math.PI * 2.0;
        int s = (int)Math.floor((angle / (Math.PI * 2.0)) * 5.0);
        return Math.max(0, Math.min(4, s));
    }

    @Override public void render(PoseStack pose, int mouseX, int mouseY, float partialTick) {
        fill(pose, 0, 0, width, height, 0x99000000);
        selected = selectedSlot(mouseX, mouseY);
        Minecraft mc = Minecraft.getInstance();
        int cx = width / 2, cy = height / 2;
        int[][] pts = {{cx,cy-78},{cx+80,cy-22},{cx+46,cy+66},{cx-46,cy+66},{cx-80,cy-22}};
        String[] labels = {"ARMA 1","ARMA 2","ARMA 3","PISTOLA","EQUIPO"};

        for (int i=0;i<5;i++) {
            int x=pts[i][0], y=pts[i][1];
            int boxColor=i==selected?0xDDF0F0F0:0xAA202020;
            fill(pose,x-42,y-27,x+42,y+27,boxColor);
            drawCenteredString(pose,font,Component.literal(labels[i]),x,y-19,i==selected?0x111111:0xFFFFFF);
            ItemStack stack=getSlotStack(mc,i);
            if(!stack.isEmpty()) {
                Minecraft.getInstance().getItemRenderer().renderGuiItem(stack,x-8,y-8);
                Minecraft.getInstance().getItemRenderer().renderGuiItemDecorations(font,stack,x-8,y-8);
                String extra="";
                if(stack.getItem() instanceof WeaponItem w){
                    WeaponItem.init(stack,w.spec());
                    var n=stack.getOrCreateTag();
                    extra=n.getInt("Ammo")+"/"+n.getInt("Reserve");
                }
                if(!extra.isEmpty()) drawCenteredString(pose,font,Component.literal(extra),x,y+21,0xFFFFFF);
            }
        }
        drawCenteredString(pose,font,Component.literal("Mantén TAB · selecciona con el ratón"),cx,height-24,0xFFFFFF);
        super.render(pose,mouseX,mouseY,partialTick);
    }

    private ItemStack getSlotStack(Minecraft mc,int wheelSlot){
        if(mc.player==null) return ItemStack.EMPTY;
        int invSlot = Math.min(wheelSlot, 4);
        return mc.player.getInventory().getItem(invSlot);
    }

    public void finishSelection(){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null)return;
        // The wheel is intentionally limited to the first five hotbar slots:
        // three long guns, one pistol, one equipment item. The machete is never a wheel slot.
        if(selected>=0 && selected<=4) mc.player.getInventory().selected=selected;
    }

    @Override public boolean isPauseScreen(){return false;}
    @Override public boolean shouldCloseOnEsc(){return false;}
}
