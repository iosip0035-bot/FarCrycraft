package com.farcrycraft.client.model;

import com.farcrycraft.FarCrycraft;
import com.farcrycraft.entity.MercenaryEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public class MercenaryRenderer extends MobRenderer<MercenaryEntity,MercenaryModel> {
    public MercenaryRenderer(EntityRendererProvider.Context ctx, ModelLayerLocation layer){super(ctx,new MercenaryModel(ctx.bakeLayer(layer)),.5f);}
    @Override public ResourceLocation getTextureLocation(MercenaryEntity e){
        return new ResourceLocation(FarCrycraft.MODID,"textures/entity/mercenary_"+e.role()+".png");
    }
}
