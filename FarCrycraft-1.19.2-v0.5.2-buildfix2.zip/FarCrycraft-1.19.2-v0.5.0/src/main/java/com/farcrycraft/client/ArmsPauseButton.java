package com.farcrycraft.client;

import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ArmsPauseButton extends Button {
    public ArmsPauseButton(int x, int y, int w, int h, OnPress press) {
        super(x, y, w, h, Component.literal("ARMS"), press);
    }
}
