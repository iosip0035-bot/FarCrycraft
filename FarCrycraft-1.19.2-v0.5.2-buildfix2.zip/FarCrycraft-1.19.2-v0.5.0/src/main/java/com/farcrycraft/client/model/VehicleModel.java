package com.farcrycraft.client.model;

import com.farcrycraft.entity.FarCryVehicleEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.renderer.RenderType;

public class VehicleModel extends EntityModel<FarCryVehicleEntity> {
    private final ModelPart body;
    private final ModelPart cabin;
    private final ModelPart rotor;
    private final ModelPart wingL;
    private final ModelPart wingR;
    private final ModelPart front;
    private final ModelPart rear;

    public VehicleModel(ModelPart root) {
        this.body = root.getChild("body");
        this.cabin = root.getChild("cabin");
        this.rotor = root.getChild("rotor");
        this.wingL = root.getChild("wing_l");
        this.wingR = root.getChild("wing_r");
        this.front = root.getChild("front");
        this.rear = root.getChild("rear");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0,0).addBox(-8,-3,-5,16,6,10), PartPose.ZERO);
        root.addOrReplaceChild("cabin", CubeListBuilder.create()
                .texOffs(0,16).addBox(-5, -7, -4, 10, 4, 8), PartPose.ZERO);
        root.addOrReplaceChild("front", CubeListBuilder.create()
                .texOffs(0,28).addBox(-7, -5, -8, 14, 2, 4), PartPose.ZERO);
        root.addOrReplaceChild("rear", CubeListBuilder.create()
                .texOffs(0,34).addBox(-7, -5, 4, 14, 2, 4), PartPose.ZERO);
        root.addOrReplaceChild("rotor", CubeListBuilder.create()
                .texOffs(0,40).addBox(-1, -10, -1, 2, 20, 2), PartPose.ZERO);
        root.addOrReplaceChild("wing_l", CubeListBuilder.create()
                .texOffs(0,44).addBox(-18, -1, -2, 10, 2, 4), PartPose.ZERO);
        root.addOrReplaceChild("wing_r", CubeListBuilder.create()
                .texOffs(0,44).addBox(8, -1, -2, 10, 2, 4), PartPose.ZERO);
        return LayerDefinition.create(mesh,64,64);
    }

    @Override public void setupAnim(FarCryVehicleEntity v,float limbSwing,float limbSwingAmount,float age,float netHeadYaw,float headPitch) {
        float spin=age*1.8f;
        rotor.yRot=spin;
        cabin.visible=v.getVehicleType()==FarCryVehicleEntity.Type.CAR || v.getVehicleType()==FarCryVehicleEntity.Type.TRUCK;
        front.visible=v.getVehicleType()==FarCryVehicleEntity.Type.CAR || v.getVehicleType()==FarCryVehicleEntity.Type.TRUCK;
        rear.visible=v.getVehicleType()==FarCryVehicleEntity.Type.CAR || v.getVehicleType()==FarCryVehicleEntity.Type.TRUCK;
        wingL.visible=v.getVehicleType()==FarCryVehicleEntity.Type.AIRPLANE;
        wingR.visible=v.getVehicleType()==FarCryVehicleEntity.Type.AIRPLANE;
        rotor.visible=v.getVehicleType()==FarCryVehicleEntity.Type.HELICOPTER;
    }

    @Override public void renderToBuffer(com.mojang.blaze3d.vertex.PoseStack ps,
            com.mojang.blaze3d.vertex.VertexConsumer vc,int light,int overlay,float r,float g,float b,float a) {
        body.render(ps,vc,light,overlay,r,g,b,a);
        cabin.render(ps,vc,light,overlay,r,g,b,a);
        rotor.render(ps,vc,light,overlay,r,g,b,a);
        wingL.render(ps,vc,light,overlay,r,g,b,a);
        wingR.render(ps,vc,light,overlay,r,g,b,a);
        front.render(ps,vc,light,overlay,r,g,b,a);
        rear.render(ps,vc,light,overlay,r,g,b,a);
    }
}
