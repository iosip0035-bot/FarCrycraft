# Far Crycraft 1.19.2 — v0.5.0-alpha

Open-world FPS foundation for Minecraft 1.19.2, built around original assets inspired by modern military/open-world shooters.

## Included in this pass
- 9 weapon classes: pistol, SMG, assault rifle, carbine, LMG, shotgun, DMR, sniper, RPG
- left-click firing packet + server-authoritative hitscan
- magazines, reserve ammo, reload packet, fire cooldown, spread, range falloff and headshots
- attachment data and Weapon Bench cycling: red dot, holo, scope, suppressor, extended mag, grip, muzzle brake
- grenades, incendiary, mine, C4, RPG and medkit
- parachute network state + glide physics
- mercenary, heavy, sniper and machine-gunner roles
- procedural outpost prototype and random defenders
- car, truck, helicopter and airplane vehicle item spawners + mount/controller foundation
- FPS HUD, reload/parachute keybinds
- original 3D item model geometry
- original humanoid model/animation source files + vehicle/arms animation source rigs
- Forge 1.19.2-43.5.2 / Java 17 / GeckoLib 3.1.40 configured

## Art direction
No original Far Cry 6 game files are included. Models/textures/animation source are original and can be iterated in Blockbench.

## Next content layer
Full bespoke weapon rigs for every attachment, final first-person arms renderer, ADS camera, weapon-specific reload clips, complete vehicle meshes with seats/damage/fuel/weapons, and a full outpost capture/alarm/reinforcement state machine are the next art/gameplay layer.

## Arm customization
Press ESC to open the normal pause menu. A small arms icon now opens the Arm Customization screen.
You can change skin tone, sleeve color, gloves, wrist band and sleeve style. Settings persist on the
client in `config/farcrycraft_arms.json` and are applied to the first-person arms model.


## Stability notes
A 1.19.2-focused cleanup pass has removed duplicate key handlers, converted client GUI code to the 1.19.2 PoseStack API, fixed missing stealth-bush resources, corrected role-specific enemy magazines, made gunshot/stealth interaction server-side, and changed reloads to use a server timer.
