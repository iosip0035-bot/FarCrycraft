@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ===============================================
echo       Far Crycraft - Build and Install
echo ===============================================
echo.

java -version >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Java was not found in PATH.
  echo Install Java 17 and run this file again.
  pause
  exit /b 1
)

echo [1/4] Checking Java...
java -version

echo.
set "GRADLE_VERSION=7.6.4"
set "TOOLS=%~dp0.tools"
set "GRADLE_HOME=%TOOLS%\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%TOOLS%\gradle-%GRADLE_VERSION%-bin.zip"
set "GRADLE_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip"

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo [2/4] Downloading Gradle %GRADLE_VERSION%...
  if not exist "%TOOLS%" mkdir "%TOOLS%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%GRADLE_URL%' -OutFile '%GRADLE_ZIP%'"
  if errorlevel 1 (
    echo [ERROR] Could not download Gradle.
    pause
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_ZIP%' '%TOOLS%'"
  if errorlevel 1 (
    echo [ERROR] Could not extract Gradle.
    pause
    exit /b 1
  )
)

echo [3/4] Compiling Far Crycraft...
call "%GRADLE_HOME%\bin\gradle.bat" build --no-daemon
if errorlevel 1 (
  echo.
  echo [ERROR] Build failed. Scroll up to see the first error.
  pause
  exit /b 1
)

set "MODJAR="
for /f "delims=" %%F in ('dir /b /o-d "build\libs\*.jar" 2^>nul ^| findstr /v /i "sources"') do (
  set "MODJAR=build\libs\%%F"
  goto :found
)

:found
if not defined MODJAR (
  echo [ERROR] Build completed but no mod JAR was found in build\libs.
  pause
  exit /b 1
)

set "MINECRAFT_MODS=%APPDATA%\.minecraft\mods"
if not exist "%MINECRAFT_MODS%" mkdir "%MINECRAFT_MODS%"

echo [4/4] Installing:
echo         %MODJAR%
echo Into:
echo         %MINECRAFT_MODS%
copy /Y "%MODJAR%" "%MINECRAFT_MODS%\" >nul
if errorlevel 1 (
  echo [ERROR] Could not copy the mod to the Minecraft mods folder.
  pause
  exit /b 1
)

echo.
echo ===============================================
echo BUILD SUCCESSFUL
for %%F in ("%MODJAR%") do echo Mod: %%~nxF
echo Installed to: %MINECRAFT_MODS%
echo ===============================================
echo.
echo Launch Minecraft 1.19.2 with Forge 43.5.2.
echo.
pause
