# Far Crycraft 0.5.1-alpha — static audit

## Fixed in this audit
- ForgeGradle corrected to the 6.0–6.2 line used by current 1.19.2 MDK examples.
- Removed unused GeckoLib build dependency; current source does not import GeckoLib.
- Added pistol/rifle/shotgun/rocket ammo registry items referenced by outpost loot.
- Added item models/textures for those ammo items.
- Added missing mercenary role textures referenced by the renderer.
- WeaponItem now uses each weapon's real default attachment set instead of always forcing RED_DOT.
- Frag/incendiary/mine/C4 and medkit are now usable items instead of inert Items.
- mods.toml version synchronized to 0.5.1-alpha.

## Static checks
- Java source files: 48
- JSON resource files: 39
- JSON parse errors: 0
- Missing internal project imports: 0
- Missing ModItems references after registry audit: 0
- Missing ModBlocks references: 0
- Missing ModEntities references: 0
- Missing custom texture references from JSON models: 0
- Entity texture paths used by renderers: present

## Not verified in this environment
The full Forge Gradle build and Minecraft runtime test were not executed because this environment
has no Gradle wrapper/cache and the container cannot reach the Forge Maven host. Java 17 is still
the target runtime for Minecraft/Forge 1.19.2.
