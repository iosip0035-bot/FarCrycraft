#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 - <<'PY'
import json,re,pathlib,sys
root=pathlib.Path('.')
errs=[]
for p in root.joinpath('src/main/resources').rglob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errs.append(f'JSON: {p}: {e}')
base=root/'src/main/java'
items=(base/'com/farcrycraft/registry/ModItems.java').read_text()
blocks=(base/'com/farcrycraft/registry/ModBlocks.java').read_text()
ents=(base/'com/farcrycraft/registry/ModEntities.java').read_text()
idecl=set(re.findall(r'RegistryObject<Item>\s+(\w+)',items))
bdecl=set(re.findall(r'RegistryObject<Block>\s+(\w+)',blocks))
edecl=set(re.findall(r'RegistryObject<EntityType<[^>]+>>\s+(\w+)',ents))
for p in base.rglob('*.java'):
    s=p.read_text()
    errs += [f'{p}: missing ModItems.{x}' for x in set(re.findall(r'ModItems\.(\w+)',s))-idecl-{'ITEMS'}]
    errs += [f'{p}: missing ModBlocks.{x}' for x in set(re.findall(r'ModBlocks\.(\w+)',s))-bdecl-{'BLOCKS'}]
    errs += [f'{p}: missing ModEntities.{x}' for x in set(re.findall(r'ModEntities\.(\w+)',s))-edecl-{'ENTITIES','Attrs'}]
if errs:
    print('\n'.join(errs)); sys.exit(1)
print('STATIC AUDIT OK')
PY
