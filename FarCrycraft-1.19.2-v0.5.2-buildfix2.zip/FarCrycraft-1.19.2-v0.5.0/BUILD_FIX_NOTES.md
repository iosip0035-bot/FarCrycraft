# Build fix after first real Forge compile

The first user-side compile reached Forge/MCP setup successfully, then exposed 111 source compatibility errors.

Root causes corrected in this pass:
- ForgeGradle moved back to the 5.1.x line appropriate for the 1.19.2 MDK generation.
- One-click builder now uses Gradle 7.6.4 with Java 17.
- Removed several APIs from newer Minecraft versions (GuiGraphics/Axis/Button.builder style, newer overlay event names, newer package locations).
- Corrected 1.19.2 BlockBehaviour/PartPose/ItemRenderer imports.
- Replaced the vehicle's conflicting getType() accessor with getVehicleType().
- Corrected 1.19.2 explosion block-interaction enum usage.
- Corrected entity save-method visibility.
- Corrected several 1.19.2 block/position helpers and overlay event accessors.
- Added the missing weapon Attachment enum/defaults used by the Weapon Bench.

This pass is source-level compatibility work. A successful Minecraft/Forge runtime build still needs to be run on the user's machine because this environment does not have the Forge dependency cache.

## Build fix 2 (1.19.2)
- Removed `copyIdeResources` from the ForgeGradle 5.1 build script; it was causing project evaluation to fail before the Minecraft dependency was configured.
- Kept ForgeGradle 5.1.+, matching the official ForgeGradle 5.x documentation for the 1.19.x toolchain.
- Fixed 1.19.2 API references for entity save methods, RandomSource and explosion interaction.
- Kept Java 17 and Forge 1.19.2-43.5.2.
